-- --------------------------------------------------------
-- Host:                         127.0.0.1
-- Server version:               8.0.34 - MySQL Community Server - GPL
-- Server OS:                    Win64
-- HeidiSQL Version:             8.1.0.4545
-- --------------------------------------------------------

/*!40101 SET @OLD_CHARACTER_SET_CLIENT=@@CHARACTER_SET_CLIENT */;
/*!40101 SET NAMES utf8 */;
/*!40014 SET @OLD_FOREIGN_KEY_CHECKS=@@FOREIGN_KEY_CHECKS, FOREIGN_KEY_CHECKS=0 */;
/*!40101 SET @OLD_SQL_MODE=@@SQL_MODE, SQL_MODE='NO_AUTO_VALUE_ON_ZERO' */;

-- Dumping structure for table hospitalproject.admin
CREATE TABLE IF NOT EXISTS `admin` (
  `id` int NOT NULL AUTO_INCREMENT,
  `username` varchar(50) DEFAULT NULL,
  `password` varchar(255) DEFAULT NULL,
  PRIMARY KEY (`id`),
  UNIQUE KEY `username` (`username`)
) ENGINE=InnoDB AUTO_INCREMENT=10 DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_0900_ai_ci;

-- Dumping data for table hospitalproject.admin: ~6 rows (approximately)
/*!40000 ALTER TABLE `admin` DISABLE KEYS */;
INSERT INTO `admin` (`id`, `username`, `password`) VALUES
	(1, 'jyotika@gmail.com', 'b00be05015bc9a96b656c33c5056876615c568d006efd692902c7676a3df8a96'),
	(2, 'arti@gmail.com', '6f16a557dfe5997d6dcce2c09e0a585ed217cfc26b9b1fa5ac4491cf7c6bc6d7'),
	(3, 'gita@gmail.com', 'c02ded4e1a87a53e4741c7ce40fc1d810b722a4e32c63d2fcb821795ad0b8ab1'),
	(6, 'komal@gmail.com', '9f35e3aeaa23da92951190a19e5ad068ec043a817b7999c025bb2248674188f5'),
	(8, 'jyoti@gmail.com', '12b361594b706aeabfc3c6c5630a8a7e1cc19591770fb1e2bac7ff4852228dba'),
	(9, 'abc@gmail.com', 'b5adcd0b0ad1abb541ba112c843d95300a4f324674465ea8be017ef0f9c38945');
/*!40000 ALTER TABLE `admin` ENABLE KEYS */;


-- Dumping structure for table hospitalproject.appointment
CREATE TABLE IF NOT EXISTS `appointment` (
  `app_id` int NOT NULL AUTO_INCREMENT,
  `appointment_date` date DEFAULT NULL,
  `status` enum('scheduled','canceled','completed') DEFAULT NULL,
  `patient_id` int DEFAULT NULL,
  `doctor_id` int DEFAULT NULL,
  `dr_specialization` varchar(30) DEFAULT NULL,
  `appointment_time` varchar(50) DEFAULT NULL,
  PRIMARY KEY (`app_id`),
  UNIQUE KEY `unique_appointment` (`doctor_id`,`appointment_date`,`appointment_time`),
  KEY `fk_patient_id` (`patient_id`),
  CONSTRAINT `fk_doctor_id` FOREIGN KEY (`doctor_id`) REFERENCES `doctor` (`did`),
  CONSTRAINT `fk_patient_id` FOREIGN KEY (`patient_id`) REFERENCES `patient` (`pid`) ON DELETE CASCADE
) ENGINE=InnoDB AUTO_INCREMENT=8 DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_0900_ai_ci;

-- Dumping data for table hospitalproject.appointment: ~9 rows (approximately)
/*!40000 ALTER TABLE `appointment` DISABLE KEYS */;
INSERT INTO `appointment` (`app_id`, `appointment_date`, `status`, `patient_id`, `doctor_id`, `dr_specialization`, `appointment_time`) VALUES
	(1, '2024-06-09', 'completed', 18, 6, 'Surgeons', '11am to 12am'),
	(2, '2024-06-07', 'completed', 19, 147, 'Neurologists', '11am to 12am'),
	(3, '2024-06-09', 'completed', 27, 147, 'Neurologists', '4pm to 5pm'),
	(4, '2024-06-07', 'scheduled', 26, 147, 'Neurologists', '12am to 1pm '),
	(5, '2024-06-03', 'scheduled', 19, 147, 'Neurologists', '12am to 1pm '),
	(7, '2024-06-03', 'scheduled', 19, 6, 'Surgeons', '12am to 1pm ');
/*!40000 ALTER TABLE `appointment` ENABLE KEYS */;


-- Dumping structure for table hospitalproject.billing
CREATE TABLE IF NOT EXISTS `billing` (
  `billing_id` int NOT NULL AUTO_INCREMENT,
  `amount` decimal(8,2) DEFAULT NULL,
  `billing_date` datetime DEFAULT CURRENT_TIMESTAMP,
  `patient_name` varchar(40) DEFAULT NULL,
  `doctor_name` varchar(40) DEFAULT NULL,
  `app_id` int DEFAULT NULL,
  PRIMARY KEY (`billing_id`),
  UNIQUE KEY `app_id` (`app_id`)
) ENGINE=InnoDB AUTO_INCREMENT=10 DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_0900_ai_ci;

-- Dumping data for table hospitalproject.billing: ~9 rows (approximately)
/*!40000 ALTER TABLE `billing` DISABLE KEYS */;
INSERT INTO `billing` (`billing_id`, `amount`, `billing_date`, `patient_name`, `doctor_name`, `app_id`) VALUES
	(1, 1000.00, '2024-06-02 00:00:00', 'Jyoti Chavan', 'Vinayak Sharma', 1),
	(4, 800.00, '2024-06-06 00:00:00', 'Amit Chavan', 'Sarika Gite', 2),
	(5, 800.00, '2024-06-06 00:00:00', 'Nitin Mali', 'Sarika Gite', 4),
	(7, 800.00, '2024-06-09 00:00:00', 'Mina Pagare', 'Sarika Gite', 3);
/*!40000 ALTER TABLE `billing` ENABLE KEYS */;


-- Dumping structure for table hospitalproject.doctor
CREATE TABLE IF NOT EXISTS `doctor` (
  `did` int NOT NULL AUTO_INCREMENT,
  `dr_name` varchar(50) DEFAULT NULL,
  `specialization` varchar(50) NOT NULL,
  `email` varchar(40) DEFAULT NULL,
  `mobile_no` bigint DEFAULT NULL,
  `dr_status` enum('Available','Unavailable') DEFAULT NULL,
  `status` tinyint(1) DEFAULT '1',
  `fees` decimal(8,2) DEFAULT NULL,
  PRIMARY KEY (`did`),
  UNIQUE KEY `email` (`email`),
  UNIQUE KEY `mobile_no` (`mobile_no`)
) ENGINE=InnoDB AUTO_INCREMENT=148 DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_0900_ai_ci;

-- Dumping data for table hospitalproject.doctor: ~14 rows (approximately)
/*!40000 ALTER TABLE `doctor` DISABLE KEYS */;
INSERT INTO `doctor` (`did`, `dr_name`, `specialization`, `email`, `mobile_no`, `dr_status`, `status`, `fees`) VALUES
	(1, ' Jyoti Chavan', 'Dentists', 'jyoti@gmail.com', 8776677866, 'Available', 0, 1000.00),
	(2, 'Vinayak Sharma', 'Dentists', 'jyotiiii@gmail.com', 8789876545, 'Available', 0, 1000.00),
	(3, 'Siya Sathe', 'Cardiologists', 'Siya@gamil.com', 9876783333, 'Available', 0, 1000.00),
	(6, 'Nitin Molay', 'Surgeons', 'nitin@gmail.com', 9876787676, 'Available', 1, 500.00),
	(45, 'kjhdkh', 'surgeons', 'jhj@gmail.com', 8989899787, 'Available', 0, 1000.00),
	(123, 'Vrunda Upadhye', 'surgeons', 'abcddff@gmail.com', 9876787989, 'Unavailable', 0, 1000.00),
	(132, 'Hkk Kjhkh', 'Surgeons', 'kdhh@gmail.com', 9876787670, 'Available', 0, 1000.00),
	(133, 'Khiuhuk Dkuyiu', 'Surgeons', 'jyoti@gamil.com', 9807980980, 'Available', 0, 1000.00),
	(137, 'Jhgjhg Hk', 'Dentists', 'jyotikakak@gmail.com', 9876700676, 'Unavailable', 0, 1000.00),
	(142, 'Siya Sathe', 'Cardiologists', 'Siya123@gamil.com', 9876787342, 'Unavailable', NULL, 1000.00),
	(143, 'Abc', 'Cardiologists', 'abc@gmail.com', 7687687687, 'Unavailable', NULL, 1000.00),
	(144, 'Hjgsjd Dbskhj', 'Neurologists', 'hgjhg@gmail.com', 7676768686, 'Available', NULL, 1000.00),
	(145, 'Jyoti Chavan', 'Cardiologists', 'jjj@gmail.com', 7887987878, 'Available', 0, NULL),
	(146, 'Hdb Dhk', 'Cardiologists', 'Bghhg@gmail.com', 7868766767, 'Available', 0, 800.00),
	(147, 'Sarika Gite', 'Cardiologists', 'sarika@gmail.com', 8676976566, 'Available', 1, 800.00);
/*!40000 ALTER TABLE `doctor` ENABLE KEYS */;


-- Dumping structure for table hospitalproject.patient
CREATE TABLE IF NOT EXISTS `patient` (
  `pid` int NOT NULL AUTO_INCREMENT,
  `name` varchar(50) NOT NULL,
  `date_of_birth` datetime DEFAULT NULL,
  `mobile_no` bigint DEFAULT NULL,
  `gender` varchar(20) DEFAULT NULL,
  `address` varchar(50) DEFAULT NULL,
  `status` tinyint(1) DEFAULT '1',
  PRIMARY KEY (`pid`),
  UNIQUE KEY `mobile_no` (`mobile_no`)
) ENGINE=InnoDB AUTO_INCREMENT=28 DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_0900_ai_ci;

-- Dumping data for table hospitalproject.patient: ~14 rows (approximately)
/*!40000 ALTER TABLE `patient` DISABLE KEYS */;
INSERT INTO `patient` (`pid`, `name`, `date_of_birth`, `mobile_no`, `gender`, `address`, `status`) VALUES
	(1, 'Nitin Mali', '2024-05-28 00:00:00', 8888888888, 'Female', 'Lkjlj', 0),
	(2, 'Jjjhkj', '2024-05-31 00:00:00', 8999999999, 'Male', 'Kjljlkj', 0),
	(3, 'Nitin Mali', '2024-05-30 00:00:00', 4444444444, 'Female', 'Vvcc', 0),
	(4, 'Sbmnb Dsdhsk', '2024-05-30 00:00:00', 9888888887, 'Male', 'Hghjghgh', 0),
	(5, 'Jhkjh', '2024-05-29 00:00:00', 9876676787, 'Female', 'Jhjkdhjd', 0),
	(6, 'Jypti', '2024-05-29 00:00:00', 7888888888, 'Male', 'Jhdjkhfj', 0),
	(7, 'Jnds Dskjhk', '2024-05-28 00:00:00', 6688767867, 'Male', 'Khgkghkgkh', 0),
	(8, 'Nilima More', '2024-05-26 00:00:00', 9876787666, 'female', 'Pune', 0),
	(9, 'Manisha Chavan', '2024-05-28 00:00:00', 7686768787, 'female', 'Hjvgjdvjg', 0),
	(10, 'Jaya Ranekkk', '2024-05-28 00:00:00', 9876787676, 'female', 'Pune', 0),
	(11, 'Bhk', '2024-05-30 00:00:00', 9807980980, 'Female', 'Khkk', 0),
	(13, 'Hkhk', '2024-05-28 00:00:00', 9807980986, 'Male', 'Hk', 0),
	(14, 'Jdhsk Sdjkshkj', '2024-05-31 00:00:00', 7687686868, 'Male', 'Jkhkjh', 0),
	(15, 'Veunda Chavan', '2024-04-11 00:00:00', 8979798798, 'Male', 'Mbb', NULL),
	(16, 'Pooja Upafhey', '2024-05-31 00:00:00', 7687676786, 'Female', 'Jhkhk', 0),
	(17, 'Jkhkh', '2024-05-31 00:00:00', 7687687677, 'Female', 'Kjhkjhj', 0),
	(18, 'Jyoti Chavan', '1996-05-11 00:00:00', 9878987878, 'Female', 'Jalna', 1),
	(19, 'Amit Chavan', '1995-09-03 00:00:00', 8976567888, 'Male', 'Nagar', 1),
	(20, 'Vurnda Chavan', '2024-05-30 00:00:00', 9878787878, 'Female', 'Pune', 1),
	(21, 'Mira Rathi', '2024-02-02 00:00:00', 9466576576, 'Female', 'Rahata', 1),
	(22, 'Kavita Roshan', '2024-05-18 00:00:00', 8097987897, 'Female', 'Pune', 1),
	(23, 'Bhakti Jadhav', '2024-06-01 00:00:00', 7656575657, 'Female', 'Pune', 1),
	(26, 'Nitin Mali', '2024-06-01 00:00:00', 8787878788, 'Female', 'Rahata', 1),
	(27, 'Mina Pagare', '2024-06-02 00:00:00', 9977545455, 'Female', 'Pune', 1);
/*!40000 ALTER TABLE `patient` ENABLE KEYS */;
/*!40101 SET SQL_MODE=IFNULL(@OLD_SQL_MODE, '') */;
/*!40014 SET FOREIGN_KEY_CHECKS=IF(@OLD_FOREIGN_KEY_CHECKS IS NULL, 1, @OLD_FOREIGN_KEY_CHECKS) */;
/*!40101 SET CHARACTER_SET_CLIENT=@OLD_CHARACTER_SET_CLIENT */;
