// Import Express framework
const express = require('express')
const router = express.Router();

const { adminLogin } = require('../controllers/admin')

// Define routes and their controller functions
router.post("/login", adminLogin)


// Export the router for use in other modules
module.exports = router;