// Import Express framework
const express = require('express')
const router = express.Router()
const verfiyLogin = require('../middleware/middleware')
const { getData, getDatabyId, addData, updateData, daleteData,softDelete } = require('../controllers/patient')

// Define routes and their controller functions
router.route('/getData').get(verfiyLogin, getData)
router.route('/getData/:id').get(verfiyLogin, getDatabyId)
router.route('/addData').post(verfiyLogin, addData)
router.route('/updateData/:id').patch(verfiyLogin, updateData)
router.route('/deleteData/:id').delete(verfiyLogin, daleteData)
// softDelete
router.route('/softDelete/:id').patch(verfiyLogin, softDelete)

// Export the router for use in other modules
module.exports = router;