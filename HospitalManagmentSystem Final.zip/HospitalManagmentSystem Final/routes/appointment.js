// Import Express framework
const express = require('express')
const router = express.Router()
const verfiyLogin = require('../middleware/middleware')
const {  addData, updateData,getAppointmentData,getAppointmentDatabyId } = require('../controllers/appointment')

// Define routes and their controller functions
router.route('/getAppointmentData').get(verfiyLogin, getAppointmentData)
router.route('/getAppointmentData/:id').get(verfiyLogin, getAppointmentDatabyId)
router.route('/addData').post(verfiyLogin, addData)
router.route('/updateData/:id').patch(verfiyLogin, updateData)

// Export the router for use in other modules
module.exports = router;