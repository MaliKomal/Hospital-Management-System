// Import Express framework
const express = require('express')
const router = express.Router()
const verfiyLogin = require('../middleware/middleware')
const { getData, getDatabyId, addData } = require('../controllers/billing')

// Define routes and their controller functions
router.route('/getData').get(verfiyLogin, getData)
router.route('/getData/:id').get(verfiyLogin, getDatabyId)
router.route('/addData').post(verfiyLogin, addData)


// Export the router for use in other modules
module.exports = router;