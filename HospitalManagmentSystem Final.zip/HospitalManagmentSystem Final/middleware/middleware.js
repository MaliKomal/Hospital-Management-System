// load environment variables from .env file
require('dotenv').config();
// get secret key from environment variables
const secretKey = process.env.JWT_SECRET;
// import JSON Web Token module
const jwt = require('jsonwebtoken');


// create middleware to verify token
const verifyToken = (req, res, next) => {
    // Extract the authorization header from the request
    const bearerHeader = req.headers['authorization'];
    //check if the authorization header is present
    if (typeof bearerHeader !== 'undefined') {
        // split the header value to extract the token
        const bearer = bearerHeader.split(" ");
        // get token from the split array
        const token = bearer[1];
        //token attach request object
        req.token = token;
        // Verify the token using the secret key
        jwt.verify(req.token, secretKey, (err, authData) => {
            if (err) {
                return res.status(401).json({ error: "Invalid token" });
            } else {
                // req.authData = authData;
                next();
            }
        });
    } else {
        res.status(401).json({ error: 'Token is not provided' });
    }
};

// Export the middleware function 
module.exports = verifyToken;
