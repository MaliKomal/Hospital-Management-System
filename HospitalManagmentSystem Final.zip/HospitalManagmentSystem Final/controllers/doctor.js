const db = require('../db')


//------------------------------------------------------------------------------------------------------
//This function retrieves doctor data from the database based on the provide doctor ID using SQL select query.
const getDatabyId = (req, res) => {
    const id = req.params.id
    const sql = "select  did,dr_name,specialization,email,mobile_no, dr_status,fees from doctor where did = ?";
    db.query(sql, [id], (err, result) => {
        if (err) {
            return res.status(400).json({ error: err })
        }
        else {
            if (result.length === 0) {
                return res.status(404).json({ error: "Doctor record not found...!" });
            }
            return res.json(result);
        }
    })
}

//--------------------------------------------------------------------------------------------------

const getData = (req, res) => {
    let sql = 
      "select  did,dr_name,specialization,email,mobile_no, dr_status,fees from doctor";
    const filters = req.query.where;
    if (Object.keys(filters).length > 0) {
      sql =  sql + " where " + filters;
    }
    db.query(sql, (err, result) => {
      if (result) {
        return res.status(200).json(result);
      } else {
        return res.status(404).json({ err: "" });
      }
    });
  };

//---------------------------------------------------------------------------------------
/*addData function add doctor details into doctor table that taken from request body.
also dispaly that details using sql select query*/

const addData= (req,res)=> {
    const  { dr_name,specialization,email,mobile_no, dr_status,fees} = req.body;
    if (!dr_name && !specialization ) {
      return  res.status(400).json({error:"Doctor Name And specialization are required..!"})
    }
    else {
    const sql ='insert into doctor(dr_name,specialization,email,mobile_no, dr_status,fees) values(?,?,?,?,?,?)';
    db.query(sql, [ dr_name,specialization,email,mobile_no, dr_status,fees], (err,result)=>{
        if(err){
           return res.status(500).json({error:err})
        }
        else{
            let insertedId = result.insertId;
            let selectQuery = "select  did,dr_name,specialization,email,mobile_no, dr_status,fees from doctor where did =?";
            db.query(selectQuery,[insertedId],(err,rows)=>{
                if(err){
                    return res.status(500).json({ error:err });
    
                }
              return  res.status(201).json({ message: 'Doctor record inserted successfully', data: rows[0] });
    
            })
        }
    })
    }
    }

//---------------------------------------------------------------------------------------------------
/* this function allows to update doctor records (that pass in request body) based on the provided doctor ID 
 that pass in url  using sql update query*/
const updateData = (req,res)=>{
    const id = req.params.id;
    const updatedData = req.body; 
    const sql = "update doctor set ? where did = ? "
    db.query(sql,[updatedData,id],(err,result)=>{
       if(err){
          res.status(500).json({error:err})
       }
       else{
          let selectQuery = "select  did,dr_name,specialization,email,mobile_no,dr_status,fees from doctor where did =?";
          db.query(selectQuery,[id],(err,rows)=>{
              if(err){
                  return res.status(500).json({ error:err });
              }
              if(result.message=== "(Rows matched: 0  Changed: 0  Warnings: 0"){
                return res.status(404).json({message:"Doctor record not Exist"})
              }
            // console.log(result.message)
            return  res.status(201).json({ message:'Doctor record updated sucessfully', data: rows[0] });
          })
      }
 
    })
 }

//---------------------------------------------------------------------------------------------------
//This function delete doctor data from the database based on the provided doctor ID using SQL delete query.
const daleteData = (req,res)=>{
    const id = req.params.id; 
        const sql = "delete from doctor  where did = ? ";
        db.query(sql, [id],(err,result)=>{
            if(err){
               return res.status(500).json({error:err})
            }
            if(result.affectedRows=== 0 ){
                return res.status(404).json({message:"Doctor record not Exist"})
              }
            else{
              return  res.status(201).json({message:"Doctor record deleted"})
            }
        }) 
    }


 // soft delete
const softDelete = (req, res) => {
    const id = req.params.id;
    const updatedData = req.body;
    const sql = "update doctor set ? where did = ? ";
    db.query(sql, [updatedData, id], (err, result) => {
      if (err) {
        console.log(err);
        res.status(500).json({ error: err });
      } else {
        return res
          .status(201)
          .json({ message: "doctor record updated sucessfully" });
      }
    });
  };
     
//export all function
module.exports = {getData,getDatabyId,addData,updateData,daleteData,softDelete}