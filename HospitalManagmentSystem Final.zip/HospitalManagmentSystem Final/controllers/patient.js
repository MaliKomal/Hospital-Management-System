const db = require("../db");

//--------------------------------------------------------------------------------------------------------
/* This function retrieves patient data from the database based on the provided patient
 ID using SQL select query.*/
const getDatabyId = (req, res) => {
  const id = req.params.id;
  const sql =
    "select pid,name,date_of_birth,mobile_no,gender,address from patient where pid = ? ";
  db.query(sql, [id], (err, result) => {
    if (err) {
      return res.status(400).json({ error: err });
    } else {
      if (result.length === 0) {
        return res.status(404).json({ error: "Patient record not found...!" });
      }
      return res.status(200).json(result);
    }
  });
};

// ---------------------------------------------------------------------------------------------------

//-----------------------------------------------------------------------------------------------------------------------------
/* this function allows to get all patient records if no query parameters are provided, 
otherwise filtering patient records based on optional query parameters*/
const getData = (req, res) => {
  let sql = 
    "select pid,name,date_of_birth,mobile_no,gender,address from patient ";
  const filters = req.query.where;
  if (Object.keys(filters).length > 0) {
    sql =  sql + " where " + filters;
  }
  db.query(sql, (err, result) => {
    if (result) {
      return res.status(200).json(result);
    } else {
      return res.status(404).json({ err: "" });
    }
  });
};

//Add Patient Data-----------------------------------------------------------------------------------
/*addData function add patient details into patient table that taken from request body.
also dispaly that details using sql select query*/

const addData = (req, res) => {
  // Extract the add details of patient from the request body
  const { name, date_of_birth, mobile_no, gender, address } = req.body;
  if (!name) {
    return res.status(400).json({ error: "Name are required..!" });
  } else {
    const sql =
      "insert into patient(name,date_of_birth,mobile_no,gender,address) values(?,?,?,?,?)";
    db.query(
      sql,
      [name, date_of_birth, mobile_no, gender, address],
      (err, result) => {
        if (err) {
          console.log(err);
          return res.status(500).json({ error: err });
        } else {
          let insertedId = result.insertId;
          let selectQuery =
            "select pid,name,date_of_birth,mobile_no,gender,address from patient where pid =?";
          db.query(selectQuery, [insertedId], (err, rows) => {
            if (err) {
              return res.status(500).json({ error: err });
            }
            return res
              .status(201)
              .json({
                message: "Patient record inserted successfully",
                data: rows[0],
              });
          });
        }
      }
    );
  }
};

//------------------------------------------------------------------------------------------------------------

/* this function allows to update patient records (that pass in request body) based on the provided patient ID 
 that pass in url  using sql update query*/
const updateData = (req, res) => {
  const id = req.params.id;
  const updatedData = req.body;
  const sql = "update patient set ? where pid = ? ";
  db.query(sql, [updatedData, id], (err, result) => {
    if (err) {
      res.status(500).json({ error: err });
    } else {
      let selectQuery =
        "select pid,name,date_of_birth,mobile_no,gender,address from patient where pid =?";
      db.query(selectQuery, [id], (err, rows) => {
        if (err) {
          return res.status(500).json({ error: err });
        }
        if (result.message === "(Rows matched: 0  Changed: 0  Warnings: 0") {
          return res.status(404).json({ message: "Patient record not Exist" });
        }
        return res
          .status(201)
          .json({
            message: "Patient record updated sucessfully",
            data: rows[0],
          });
      });
    }
  });
};

//----------------------------------------------------------------------------------------------------------
//This function delete patient data from the database based on the provided patient ID using SQL delete query.
// Hard delete
const daleteData = (req, res) => {
  const id = req.params.id;
  const sql = "delete from patient  where pid = ? ";
  db.query(sql, [id], (err, result) => {
    if (err) {
      return res.status(500).json({ error: err });
    }
    if (result.affectedRows === 0) {
      return res.status(404).json({ message: "Patient record not Exist" });
    } else {
      return res
        .status(201)
        .json({ message: "Patient record  deleted sucessfully" });
    }
  });
};

// soft delete
const softDelete = (req, res) => {
  const id = req.params.id;
  const updatedData = req.body;
  const sql = "update patient set ? where pid = ? ";
  db.query(sql, [updatedData, id], (err, result) => {
    if (err) {
      console.log(err);
      res.status(500).json({ error: err });
    } else {
      return res
        .status(201)
        .json({ message: "Patient record updated sucessfully" });
    }
  });
};

//export all function
module.exports = {
  getData,
  getDatabyId,
  addData,
  updateData,
  daleteData,
  softDelete,
};
