// Load environment variables from .env file
require('dotenv').config();
//Import database connection module
const db = require('../db');
// Import module for working with JSON Web Tokens (JWTs)
const jwt = require('jsonwebtoken');
// Import module for cryptographic operations
const crypto = require('crypto');
// Get secret Key from environment variable
const secretKey = process.env.JWT_SECRET;



//admin login--------------------------------------------------------------------------------------
//adminLogin funtion perform login for admin. If username and password is valid then token created.
const adminLogin = (req, res) => {

  // Extract username and password from request body
  const { username, password } = req.body;
  // SQL query to select username and password from admin
  const sql = 'select username, password from admin where username = ?';
  db.query(sql, [username], (err, results) => {
    if (err) {
      return res.status(500).json({ error: err });
    }
    if (results.length === 0) {
      return res.status(401).json({ message: 'Invalid username' });
    }
    // get hashed password from the database
    const hashedPasswordDatabase = results[0].password;
    // password provided by the user covert into hash
    const hashedPasswordFromUser = crypto.createHash('sha256').update(password).digest('hex');
    if (hashedPasswordDatabase === hashedPasswordFromUser) {
      //If passwords match, generate a JWT token
      jwt.sign({ username }, secretKey, { expiresIn: '1 day' }, (err, token) => {
        if (err) {
          return res.status(500).json({ error: 'Failed to create token' });
        }
        else {
          return res.status(200).json({ message: "Login Successfull...!", token: token })
        }

      });
    }
    else {
      res.status(401).json({ message: 'Invalid password' });
    }
  });
};


//export all function
module.exports = { adminLogin };

