const db = require('../db')


//--------------------------------------------------------------------------------------------------------------
/*addData function add appointment details into appointment table that taken from request body.
also dispaly that details using sql select query*/

const addData = (req, res) => {
     // Extract the add details of appointment from the request body
    const { appointment_date, status, patient_id, doctor_id,dr_specialization,appointment_time } = req.body;
    if (!appointment_date && !status && !patient_id && !doctor_id && !appointment_time) {
        return res.status(400).json({ error: "All feilds are required..!" })
    }
    else {
        // Execute the SQL query with the provided data
        const sql = 'insert into  appointment(appointment_date, status, patient_id, doctor_id,dr_specialization,appointment_time) values(?,?,?,?,?,?)';
        db.query(sql, [appointment_date, status, patient_id, doctor_id,dr_specialization,appointment_time], (err, result) => {
            if (err) {
                return res.status(500).json({ error: err })
            }
            else {
                let insertedId = result.insertId;
                let selectQuery = "select  app_id, appointment_date, status, patient_id, doctor_id,dr_specialization,appointment_time from  appointment where app_id =?";
                db.query(selectQuery, [insertedId], (err, rows) => {
                    if (err) {
                        return res.status(500).json({ error: err });

                    }
                    return res.status(201).json({ message: 'Appoinnment record inserted successfully', data: rows[0] });

                })
            }
        })
    }
}

//--------------------------------------------------------------------------------------------
/* this function allows to update appointment records (that pass in request body) based on the
 provided appointment ID that pass in url using sql update query*/
const updateData = (req, res) => {
    const id = req.params.id;
    const updatedData = req.body;
    const sql = "update appointment set ? where app_id = ? "
    console.log(sql)
    db.query(sql, [updatedData, id], (err, result) => {
        if (err) {
            res.status(500).json({ error: err })
        }
       
        else {
            let selectQuery = "select  app_id, appointment_date, status, patient_id, doctor_id,dr_specialization,appointment_time from  appointment where app_id =?";
            db.query(selectQuery, [id], (err, rows) => {
                if (err) {
                    return res.status(500).json({ error: err });
                }
                if (result.message === "(Rows matched: 0  Changed: 0  Warnings: 0") {
                    return res.status(404).json({ message: "Appointment Record not Exist" })
                }
                return res.status(201).json({ message: 'Appoinnment record updated sucessfully', data: rows[0] });
            })
        }

    })
}


// get appintment, doctor, and patint data

const getAppointmentData = (req, res) => {
    let sql = "select p.name AS patient_name, a.app_id, a.appointment_date, a.status,a.appointment_time,d.specialization As dr_specialization, d.dr_name AS doctor_name,d.fees as doctor_fees  from appointment a inner join patient p on a.patient_id = p.pid inner join doctor d on a.doctor_id = d.did";
    db.query(sql, (err, result) => {
        if (err) {
            return res.status(400).json({ error: err });
        } else {
            if (result.length === 0) {
                return res.status(404).json({ error: "Appointment record not found...!" });
            }
            return res.json(result);
        }
    });
};

// get appintment, doctor, and patint data by id

const getAppointmentDatabyId = (req, res) => {
    const id = req.params.id;
    let sql = "select p.name as patient_name, a.app_id, a.appointment_date, a.status, a.appointment_time, d.specialization as dr_specialization, d.dr_name as doctor_name  from appointment a  inner join patient p on a.patient_id = p.pid  inner join doctor d on a.doctor_id = d.did where a.app_id  = ?;"
       db.query(sql,[id], (err, result) => {
        if (err) {
            return res.status(400).json({ error: err });
        } else {
            if (result.length === 0) {
                return res.status(404).json({ error: "Appointment record not found...!" });
            }
            return res.json(result);
        }
    });
};


//export all function
module.exports = {  addData, updateData,getAppointmentData,getAppointmentDatabyId }