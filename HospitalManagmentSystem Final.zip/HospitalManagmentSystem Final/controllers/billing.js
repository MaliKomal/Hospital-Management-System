const db = require('../db')


//-------------------------------------------------------------------------------------------------------------
//This function retrieves billing data from the database based on the provided billing ID using SQL select query.
const getDatabyId = (req, res) => {
    const id = req.params.id
    const sql = "select billing_id, amount, billing_date,patient_name, doctor_name,app_id  from billing where billing_id = ?";
    db.query(sql, [id], (err, result) => {
        if (err) {
            return res.status(400).json({ error: err })
        }
        else {
            if (result.length === 0) {
                return res.status(404).json({ error: "billing record not found...!" });
            }
            return res.json(result);
        }
    })
}

//---------------------------------------------------------------------------------------------------
/* this function allows to get all billing records if no query parameters are provided, 
otherwise filtering billing records based on optional query parameters*/
const getData = (req, res) => {
    let sql = "select  billing_id, amount, billing_date,patient_name, doctor_name,app_id from billing";
    const filters = req.query;
    if (Object.keys(filters).length > 0) {
        sql += " where ";
        const conditions = [];
        for (const key in filters) {
            if (filters.hasOwnProperty(key)) {
                conditions.push(`${key} = '${filters[key]}'`);
            }
        }
        sql += conditions.join(" and ");
    }
    db.query(sql, (err, result) => {
        if (result.length === 0) {
            return res.status(404).json({ error: "billing record not found...!" });
        } else {
            return res.status(200).json(result);
        }
    });
};

//--------------------------------------------------------------------------------------------
/*addData function add billing details into billing table that taken from request body.
also dispaly that details using sql select query*/

const addData= (req,res)=> {
     
    const  { amount, billing_date,patient_name, doctor_name,app_id} = req.body;
    if (!amount && !billing_date && !patient_name && !doctor_name && !app_id) {
      return  res.status(400).json({error:"All Feilds are required..!"})
    }
    else {
    const sql ='insert into billing(amount, billing_date,patient_name,doctor_name,app_id) values(?,?,?,?,?)';
    db.query(sql, [ amount, billing_date,patient_name,doctor_name,app_id], (err,result)=>{
        if(err){
           return res.status(500).json({error:err})
        }
        else{
            let insertedId = result.insertId;
            let selectQuery = "select billing_id, amount, billing_date from billing where billing_id =?";
            db.query(selectQuery,[insertedId],(err,rows)=>{
                if(err){
                    return res.status(500).json({ error:err });
    
                }
              return  res.status(201).json({ message: 'Billing record inserted successfully', data: rows[0] });
    
            })
        }
    })
    }
    }

//export all function    
module.exports = {getData,getDatabyId,addData}