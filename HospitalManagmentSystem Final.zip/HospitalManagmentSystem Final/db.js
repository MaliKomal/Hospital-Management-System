// Load environment variables from .env file
require('dotenv').config();
// Import MySQL module
const mysql = require('mysql')
// Create a MySQL connection using the credentials from environment variables
const con = mysql.createConnection({
    host: process.env.DATABASE_HOST,
    user: process.env.DATABASE_USER,
    password: process.env.DATABASE_PASSWORD,
    database: process.env.DATABASE_NAME
})

con.connect((error) => {
    if (error){
    
         throw error
        }
    else{
    console.log("connect")
    }
})

// Export the MySQL connection 
module.exports = con;