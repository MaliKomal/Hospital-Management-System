export function isEmailValid(email) {
    return /^[\w-\.]+@([\w]+)\.[\w-]{2,3}$/.test(email)
    ? "" 
    : "Email is invalid";
  }
  export function isPasswordValid(password) {
    return /^(?=.*[a-z])(?=.*[A-Z])(?=.*\d)(?=.*[@$!%*?&])[A-Za-z\d@$!%*?&]{8,15}$/.test(password)
      ? ""
      : "Password is invalid ";
  }

  export function isNameValid(name) {
    return /^[A-Za-z\s]+$/.test(name)
    ? "" 
    : "Name should contain only letters";
  }
  
  export function  isMobileValid(mobile_no) {
    return /^\d{10}$/.test(mobile_no) 
    ? "" 
    : "Only 10 digit number allowed";
  }

  export function  isFessValid(fees) {
    return /^\d{3}$/.test(fees) 
    ? "" 
    : "Only number allowed";
  }

  //capitalize Each Word of name of patient
  export function capitalizeEachWord(value) {
    const words = value.split(/\s+/);
    const capitalizedWords = words.map((word) => {
      return word.charAt(0).toUpperCase() + word.slice(1);
    });
    return capitalizedWords.join(" ");
  }