import axios from 'axios';

export function postLoginData(user) {
    const postDataUrl= axios.post('http://127.0.0.1:8000/api/admin/login',user)
    return postDataUrl ;
}
// get patient data
export function getPatientData(userStatus) {
    const getDataUrl= axios.get(`http://127.0.0.1:8000/api/patient/getData/?where=status=` + userStatus,{
        headers: {
            'Authorization': 'Bearer ' + localStorage.getItem('token') 
        }
    })
    return getDataUrl ;
}
// add patient Data
export function addPatientData(newData) {

    const addDataUrl= axios.post('http://127.0.0.1:8000/api/patient/addData' , newData ,{
        headers: {
            'Authorization': 'Bearer ' + localStorage.getItem('token') 
          }
    })
    return addDataUrl ;
}
  // get patient data by id
export function getPatientDataById(patientId){
  
    const getDataUrl= axios.get('http://127.0.0.1:8000/api/patient/getData/' + patientId,{
        headers: {
            'Authorization': 'Bearer ' + localStorage.getItem('token') 
        }
    })
    return getDataUrl;
    
  }
    // Update patient data by id
export function updatePatientData(patientId,updateData){
  
    const updateDataUrl= axios.patch('http://127.0.0.1:8000/api/patient/updateData/' + patientId,
     updateData,{
        headers: {
            'Authorization': 'Bearer ' + localStorage.getItem('token') 
        }
    })
    return updateDataUrl;
  }

//   soft delete
  // delete patient data by id
  export function softDeletePatientData(patientId,updateData){
  
    const updateDataUrl= axios.patch('http://127.0.0.1:8000/api/patient/softDelete/' + patientId,
     updateData,{
        headers: {
            'Authorization': 'Bearer ' + localStorage.getItem('token') 
        }
    })
    return updateDataUrl;
  }

//get doctor data
export function getDoctorData(doctorStatus) {
    const getDataUrl= axios.get(`http://127.0.0.1:8000/api/doctor/getData/?where=status=` + doctorStatus,{
        headers: {
            'Authorization': 'Bearer ' + localStorage.getItem('token') 
        }
    })
    return getDataUrl ;
}
// add patient Data
export function addDoctorData(newData) {

    const addDataUrl= axios.post('http://127.0.0.1:8000/api/doctor/addData' , newData ,{
        headers: {
            'Authorization': 'Bearer ' + localStorage.getItem('token') 
          }
    })
    return addDataUrl ;
}


  //   soft delete
  // delete patient data by id
  export function softDeleteDoctorData(doctorId,updateData){
  
    const updateDataUrl= axios.patch('http://127.0.0.1:8000/api/doctor/softDelete/' + doctorId,
     updateData,{
        headers: {
            'Authorization': 'Bearer ' + localStorage.getItem('token') 
        }
    })
    return updateDataUrl;
  }
    // get doctor data by id
export function getDoctorDataById(doctorId){
  
    const getDataUrl= axios.get('http://127.0.0.1:8000/api/doctor/getData/' + doctorId,{
        headers: {
            'Authorization': 'Bearer ' + localStorage.getItem('token') 
        }
    })
    return getDataUrl;
    
  }
    // Update patient data by id
export function updateDoctorData(doctorId,updateData){
  
    const updateDataUrl= axios.patch('http://127.0.0.1:8000/api/doctor/updateData/' + doctorId,
     updateData,{
        headers: {
            'Authorization': 'Bearer ' + localStorage.getItem('token') 
        }
    })
    return updateDataUrl;
  }



//get appointment data
export function getAppointmentData() {
    const getDataUrl= axios.get('http://127.0.0.1:8000/api/appointment/getAppointmentData' ,{
        headers: {
            'Authorization': 'Bearer ' + localStorage.getItem('token') // Assuming you're using a JWT token
        }
    })
    return getDataUrl ;
}
// add apointment Data
export function addAppointmentData(newData) {

    const addDataUrl= axios.post('http://127.0.0.1:8000/api/appointment/addData' , newData ,{
        headers: {
            'Authorization': 'Bearer ' + localStorage.getItem('token') 
          }
    })
    return addDataUrl ;
}

     // get appointment data by id
export function getAppointmentDataById(appointmentId){
  
    const getDataUrl= axios.get('http://127.0.0.1:8000/api/appointment/getAppointmentData/' +appointmentId,{
        headers: {
            'Authorization': 'Bearer ' + localStorage.getItem('token') 
        }
    })
    return getDataUrl;
    
  }
    // Update appointment data by id
export function updateAppointmentData(appointmentId,updateData){
  
    const updateDataUrl= axios.patch('http://127.0.0.1:8000/api/appointment/updateData/' + appointmentId,
     updateData,{
        headers: {
            'Authorization': 'Bearer ' + localStorage.getItem('token') 
        }
    })
    return updateDataUrl;
  }

//get billing data
export function getBillingData() {
    const getDataUrl= axios.get('http://127.0.0.1:8000/api/billing/getData',{
        headers: {
            'Authorization': 'Bearer ' + localStorage.getItem('token') // Assuming you're using a JWT token
        }
    })
    return getDataUrl ;
}
// add Billing Data
export function addBillingData(newData) {

    const addDataUrl= axios.post('http://127.0.0.1:8000/api/billing/addData' , newData ,{
        headers: {
            'Authorization': 'Bearer ' + localStorage.getItem('token') 
          }
    })
    return addDataUrl ;
}


