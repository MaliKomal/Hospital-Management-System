<template>
  <div>
    <div class="flex justify-center items-center h-screen">
      <div class="max-w-lg w-full bg-white p-10 rounded-lg shadow-2xl">
        <div class="flex justify-center">
          <img src="../assets/images/logo2.png" class="h-20 w-30" />
        </div>
        <h2 class="text-4xl font-bold font-serif text-center my-4 text-red-700">
          Hospital Managment
        </h2>
        <hr class="border-1 border-red-200" />
        <h2 class="text-3xl font-semibold font-serif text-center my-3 text-black-800">
          Admin Login
        </h2>
        <form @submit.prevent="submitLogin">
          <div class="mb-4">
            <label for="" class="text-lg font-semibold"
              >Email<sup class="text-red-500">*</sup></label
            >
            <input
              type="text"
              placeholder="Email"
              v-model.trim="formValues.username"
              :class="{ 'border-red-500': userNameIsRequird && isLogin }"
              class="w-full px-3 py-2 mt-1 border-2 border-black outline-none focus:border-black-500 rounded-md"
            />
            <span v-if="isLogin" class="text-red-500 text-sm">{{
              userNameIsRequird
            }}</span>
          </div>
          <div class="mb-4">
            <label for="" class="text-lg font-semibold"
              >Password<sup class="text-red-500">*</sup></label
            >
            <input
              type="password"
              placeholder="Password"
              v-model.trim="formValues.password"
              :class="{ 'border-red-500': passwordIsRequired && isLogin }"
              class="w-full px-3 py-2 mt-1 border-2 border-black outline-none focus:border-black-500 rounded-md"
            />
            <span v-if="isLogin" class="text-red-500 text-sm">{{
              passwordIsRequired
            }}</span>
          </div>
          <div class="text-center">
            <button
              type="submit"
              class="w-full text-xl font-medium bg-red-800 text-white px-4 py-2 my-5 rounded-md"
            >
              Login
            </button>
          </div>
        </form>
      </div>
    </div>
  </div>
</template>

<script>
// import axios from "axios";
import { postLoginData } from "../services/apiService.js";
import {
  isEmailValid,
  isPasswordValid,
} from "../services/userServices/fromValidationMethods.js";

export default {
  name: "Login",

  data() {
    return {
      formValues: {
        username: "",
        password: "",
      },
      isLogin: false,
    };
  },
  methods: {
    submitLogin() {
      this.isLogin = true;

      if (!this.userNameIsRequird && !this.passwordIsRequired) {
        console.log("Form values", this.formValues);
        const user = {
          username: this.formValues.username,
          password: this.formValues.password,
        };

        // call  postData method to make the HTTP request
        this.postData(user);
      }
    },
    postData(user) {
      postLoginData(user)
        .then((response) => {
          console.log(response);
          if (response.data && response.data.token) {
            // stored token in local storage
            localStorage.setItem("token", response.data.token);
            // alert("Login sucessfull...");
            this.$router.push({ name: "ShowPatient" });
          } else {
            console.error("Token not found in response");
          }
        })
        .catch((error) => {
          if (
            error.response &&
            error.response.status === 401 &&
            error.response.data &&
            (error.response.data.message === "Invalid password" ||
              error.response.data.message === "Invalid username")
          ) {
            alert("Invalid credentials.... ");
          } else {
            console.error("Error:", error);
          }
        });
    },
  },
  computed: {
    userNameIsRequird() {
      return this.formValues.username
        ? isEmailValid(this.formValues.username)
        : "Email is required";
    },
    passwordIsRequired() {
      return this.formValues.password
        ? isPasswordValid(this.formValues.password)
        : "Password is required";
    },
  },
};
</script>
<style scoped></style>
