<template>
  <div>
    <mainHeader></mainHeader>

    <div class="w-screen flex flex-row pt-16">
      <div class="w-1/6">
        <navbar></navbar>
      </div>
      <div class="flex-grow pt-5">
        <div class="max-w-xl mx-auto">
          <div class="flex justify-end mb-5">
            <button
              @click="goBackShowDaoctor"
              class="bg-red-800 text-white font-bold py-1 px-4 rounded-md"
            >
              Go Back
            </button>
          </div>
          <form
            @submit.prevent="submitForm"
            class="border shadow-md shadow-red-800 rounded px-8 mb-5"
          >
            <h2 class="text-3xl font-bold my-5 text-center text-red-800">Add Doctor</h2>
            <div class="mb-4">
              <label class="block text-sm font-bold mb-2" for="name"> Name </label>
              <input
                class="shadow border rounded w-full py-2 px-3"
                id="name"
                type="text"
                placeholder="Enter Name"
                maxlength="15"
                v-model.trim="formValues.name"
                :class="{ 'border-red-500': nameIsRequired && isSubmit }"
              />
              <span v-if="isSubmit" class="text-red-500 text-sm">{{
                nameIsRequired
              }}</span>
            </div>
            <div class="mb-4">
              <label class="block text-sm font-bold mb-2" for="specialization">
                Specialization
              </label>

              <select
                class="shadow border rounded w-full py-2 px-3 text-gray-700"
                id="specialization"
                v-model="formValues.specialization"
                :class="{ 'border-red-500': specializationIsRequired && isSubmit }"
              >
                <option value="" disabled>Select Specialization</option>
                <option
                  v-for="specialization in doctorSpecialization"
                  :value="specialization"
                >
                  {{ specialization }}
                </option>
              </select>
              <span v-if="isSubmit" class="text-red-500 text-sm">{{
                specializationIsRequired
              }}</span>
            </div>
            <div class="mb-2">
              <label class="block text-sm font-bold mb-2" for="mobNo">
                Mobile Number
              </label>
              <input
                class="shadow border rounded w-full py-2 px-3"
                id="mobNo"
                type="text"
                maxlength="10"
                placeholder="Enter Mobile Number"
                v-model="formValues.mobileNumber"
                :class="{ 'border-red-500': mobileIsRequired && isSubmit }"
              />
              <span v-if="isSubmit" class="text-red-500 text-sm">{{
                mobileIsRequired
              }}</span>
            </div>
            <div class="mb-2">
              <label class="block text-sm font-bold mb-2" for="email"> Email </label>
              <input
                class="shadow border rounded w-full py-2 px-3"
                id="email"
                type="text"
                maxlength="30"
                placeholder="Enter Email"
                v-model="formValues.email"
                :class="{ 'border-red-500': emailIsRequird && isSubmit }"
              />
              <span v-if="isSubmit" class="text-red-500 text-sm">{{
                emailIsRequird
              }}</span>
            </div>

            <div class="mb-2 flex flex-wrap">
              <div class="w-full md:w-1/2 px-3 mb-4">
                <label class="block text-sm font-bold mb-4"> Doctor Status</label>
                <div class="flex">
                  <label class="inline-flex items-center mr-4">
                    <input
                      type="radio"
                      class="form-radio"
                      name="status"
                      value="Available"
                      v-model="formValues.doctorStatus"
                    />
                    <span class="ml-2">Available</span>
                  </label>
                  <label class="inline-flex items-center  text-gray-400">
                    <input
                      type="radio"
                      class="form-radio"
                      name="status"
                      value="Unavailable"
                      disabled
                      v-model="formValues.doctorStatus"
                    />
                    <span class="ml-2">Unavailable</span>
                  </label>
                </div>
                <span v-if="isSubmit" class="text-red-500 text-sm">{{
                  doctorStatusRequired
                }}</span>
              </div>
              <div class="w-full md:w-1/2 px-3 mb-4">
                <label class="block text-sm font-bold mb-2" for="fees">
                  Doctor Fees
                </label>
                <input
                  class="shadow border rounded w-full py-2 px-3"
                  id="fees"
                  type="text"
                  maxlength="10"
                  placeholder="Enter Doctor Fees"
                  v-model="formValues.doctorFees"
                  :class="{ 'border-red-500': doctorFeesRequired && isSubmit }"
                />
                <span v-if="isSubmit" class="text-red-500 text-sm">{{
                  doctorFeesRequired
                }}</span>
              </div>
            </div>
            <div class="flex items-center justify-center">
              <button
                class="bg-red-800 text-white font-bold py-2 px-10 my-5 rounded"
                type="submit"
              >
                Add
              </button>
            </div>
          </form>
          <!-- go back to show Patient record -->
        </div>
      </div>
    </div>
  </div>
</template>

<script>
import navbar from "../components/shared/Navbar.vue";
import mainHeader from "../components/shared/MainHeader.vue";
import { addDoctorData } from "../services/apiService.js";
import {
  isEmailValid,
  isNameValid,
  isMobileValid,
  capitalizeEachWord,
  isFessValid,
} from "../services/userServices/fromValidationMethods.js";

export default {
  name: "AddDoctor",
  components: { navbar, mainHeader },
  data() {
    return {
      formValues: {
        name: "",
        specialization: "",
        mobileNumber: "",
        email: "",
        doctorFees: "",
        doctorStatus: "Available",
      },
      doctorSpecialization: [
        "Cardiologists",
        "Dentists",
        "Surgeons",
        "Neurologists",
        "Psychiatrists",
      ],
      isSubmit: false,
    };
  },
  methods: {
    goBackShowDaoctor() {
      this.$router.push({ name: "ShowDoctor" });
    },
    submitForm() {
      this.isSubmit = true;
      if (
        !this.nameIsRequired &&
        !this.mobileIsRequired &&
        !this.emailIsRequird &&
        !this.specializationIsRequired &&
        !this.doctorStatusRequired &&
        !this.doctorFeesRequired
      ) {
        console.log("FormValues: ", this.formValues);
        const doctorData = {
          dr_name: capitalizeEachWord(this.formValues.name),
          specialization: this.formValues.specialization,
          mobile_no: this.formValues.mobileNumber,
          email: this.formValues.email,
          dr_status: this.formValues.doctorStatus,
          fees: this.formValues.doctorFees,
        };

        this.addDoctor(doctorData);
      }
    },
    // add doctor data
    addDoctor(doctorData) {
      addDoctorData(doctorData)
        .then((response) => {
          console.log(response);
          this.$router.push({ name: "ShowDoctor" });
        })
        .catch((error) => {
          if (
            error.response &&
            error.response.data &&
            error.response.data.error &&
            error.response.data.error.code === "ER_DUP_ENTRY"
          ) {
            // Check  duplicate email entry
            if (
              error.response.data.error.sqlMessage.includes("Duplicate entry") &&
              error.response.data.error.sqlMessage.includes("for key 'doctor.email'")
            ) {
              alert("Email already exists");
            }
            // Check duplicate mobile number entry
            else if (
              error.response.data.error.sqlMessage.includes("Duplicate entry") &&
              error.response.data.error.sqlMessage.includes("for key 'doctor.mobile_no'")
            ) {
              alert("Mobile number already exists");
            }
          } else {
            console.log(error);
          }
        });
    },
  },
  computed: {
    nameIsRequired() {
      return this.formValues.name
        ? isNameValid(this.formValues.name)
        : "Field is required";
    },

    mobileIsRequired() {
      return this.formValues.mobileNumber
        ? isMobileValid(this.formValues.mobileNumber)
        : "Field is required";
    },
    emailIsRequird() {
      return this.formValues.email
        ? isEmailValid(this.formValues.email)
        : "Email is required";
    },

    specializationIsRequired() {
      return this.formValues.specialization ? "" : "Field is required";
    },
    doctorStatusRequired() {
      return this.formValues.doctorStatus ? "" : "Please select Status";
    },
    doctorFeesRequired() {
      return this.formValues.doctorFees
        ? isFessValid(this.formValues.doctorFees)
        : "Field is required";
    },
  },
};
</script>

<style scoped></style>
