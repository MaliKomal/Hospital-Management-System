<template>
  <div>
    <mainHeader></mainHeader>

    <div class="w-screen flex flex-row pt-16">
      <div class="w-1/6">
        <navbar></navbar>
      </div>
      <div class="flex-grow pt-10">
        <div class="max-w-xxl mx-40">
          <div class="flex justify-end mb-5">
            <button
              @click="goBackShowAppointment"
              class="bg-red-800 text-white font-bold py-1 px-3 rounded-md"
            >
              Go Back
            </button>
          </div>
          <form
            @submit.prevent="submitForm"
            class="bg-white border shadow-md shadow-red-800 rounded px-10 pb-2 mb-4 flex flex-wrap"
          >
            <div class="w-full flex justify-center py-3">
              <h2 class="text-3xl font-bold my-5 text-red-800">Add Appointment</h2>
            </div>

            <div class="w-full md:w-1/2 px-3 mb-4">
              <label class="block text-sm font-bold pt-3 pb-1" for="pName">
                Patient Name
              </label>
              <input
                class="shadow border rounded w-full py-2 px-3 bg-slate-200 opacity-60"
                id="pName"
                type="text"
                v-model="formValues.patientName"
                readonly
              />
              <label class="block text-sm font-bold pt-3 pb-1" for="drName">
                Doctor Name
              </label>
              <select
                id="drName"
                v-model="formValues.doctorName"
                class="shadow border rounded w-full py-2 px-3"
                :class="{ 'border-red-500': doctorNameIsRequired && isSubmit }"
              >
                <option value="" disabled>Select Doctors</option>
                <option
                  v-for="doctor in availableDoctors"
                  :key="doctor.did"
                  :value="doctor.did"
                >
                  {{ doctor.dr_name }}
                </option>
              </select>
              <span v-if="isSubmit" class="text-red-500 text-sm">{{
                doctorNameIsRequired
              }}</span>

              <!-- doctor specilization -->
              <label class="block text-sm font-bold pt-3 pb-1" for="doctorSpec">
                Doctor Specification
              </label>
              <input
                class="shadow border rounded w-full py-2 px-3"
                id="doctorSpec"
                type="text"
                v-model="doctorSpecilization"
                readonly
                :class="{ 'border-red-500': specializationIsRequired && isSubmit }"
              />
              <span v-if="isSubmit" class="text-red-500 text-sm">{{
                specializationIsRequired
              }}</span>
            </div>

            <div class="w-full md:w-1/2 px-3 mb-4">
              <label class="block text-sm font-bold pt-3 pb-1" for="dob"
                >Appointment Date
              </label>
              <input
                class="shadow border rounded w-full py-2 px-3"
                id="dob"
                type="date"
                :min="minDate"
                :max="maxDate"
                v-model="formValues.appointmentDate"
                :class="{ 'border-red-500': dateIsRequired && isSubmit }"
              />
              <span v-if="isSubmit" class="text-red-500 text-sm">{{
                dateIsRequired
              }}</span>
              <label class="block text-sm font-bold pt-3 pb-1" for="specialization">
                Appointment Time
              </label>

              <select
                class="shadow border rounded w-full py-2 px-3 text-gray-700"
                id="specialization"
                v-model="formValues.appointmentTime"
                :class="{ 'border-red-500': timeIsRequired && isSubmit }"
              >
                <option value="" disabled>Select Time</option>
                <option v-for="time in timeSlots" :value="time">
                  {{ time }}
                </option>
              </select>
              <span v-if="isSubmit" class="text-red-500 text-sm">{{
                timeIsRequired
              }}</span>

              <!-- appintment status -->
              <label class="block text-sm font-bold pt-3 pb-1"> Appointment Status</label>
              <div class="flex">
                <label class="inline-flex items-center mr-4">
                  <input
                    type="radio"
                    class="form-radio"
                    name="status"
                    value="scheduled"
                    v-model="formValues.appointmentStatus"
                  />
                  <span class="ml-2">Scheduled</span>
                </label>
                <label class="inline-flex items-center mr-4 text-gray-400">
                  <input
                    type="radio"
                    class="form-radio"
                    name="status"
                    value="canceled"
                    disabled
                    v-model="formValues.appointmentStatus"
                  />
                  <span class="ml-2">Canceled</span>
                </label>
                <label class="inline-flex items-center text-gray-400">
                  <input
                    type="radio"
                    class="form-radio"
                    name="status"
                    value="completed"
                    disabled
                    v-model="formValues.appointmentStatus"
                  />
                  <span class="ml-2">Completed</span>
                </label>
              </div>
            </div>

            <div class="w-full flex justify-center py-5">
              <button
                class="bg-red-800 text-white font-bold py-2 px-20 my-2 rounded"
                type="submit"
              >
                Add
              </button>
            </div>
          </form>
        </div>
      </div>
    </div>
  </div>
</template>

<script>
import navbar from "../components/shared/Navbar.vue";
import mainHeader from "../components/shared/MainHeader.vue";
import { addAppointmentData, getDoctorData } from "../services/apiService.js";
export default {
  name: "AddAppointment",
  components: { navbar, mainHeader },
  data() {
    return {
      formValues: {
        appointmentDate: "",
        appointmentStatus: "scheduled",
        patientName: "",
        doctorName: "",
        appointmentTime: "",
      },
      timeSlots: [
        "10am to 11am",
        "11am to 12am",
        "12am to 1pm ",
        "1pm to 2pm",
        "3pm to 4pm",
        "4pm to 5pm",
      ],
      isSubmit: false,
      patientId: null,
      doctorId: null,
      doctorStatus: 1,
      availableDoctors: [],
      doctorSpecilization: "",
      minDate: new Date().toISOString().split("T")[0],
      maxDate: new Date(new Date().getTime() + 8 * 24 * 60 * 60 * 1000)
        .toISOString()
        .split("T")[0],
    };
  },
  mounted() {
    this.patientId = this.$route.query?.pId;
    // this.doctorId = this.$route.query?.dID
    this.formValues.patientName = this.$route.query?.pName;
    //  bind today date by default to appointment date

    this.formValues.appointmentDate = new Date().toISOString().split("T")[0];

    this.getData();
  },
  methods: {
    goBackShowAppointment() {
      this.$router.push({ name: "ShowAppointment" });
    },
    submitForm() {
      this.isSubmit = true;
      if (!this.doctorNameIsRequired && !this.timeIsRequired) {
        console.log("FormValues: ", this.formValues);
        const appointmentData = {
          appointment_date: this.formValues.appointmentDate,
          status: this.formValues.appointmentStatus,
          patient_id: this.patientId,
          doctor_id: this.formValues.doctorName,
          dr_specialization: this.doctorSpecilization,
          appointment_time: this.formValues.appointmentTime,
        };

        this.addAppointment(appointmentData);
      }
    },
    //function to get doctor record
    getData() {
      getDoctorData(this.doctorStatus)
        .then((response) => {
          console.log(response.data);
          this.availableDoctors = response.data.filter(
            (doctor) => doctor.dr_status === "Available"
          );
          // this.availableDoctorNames = availableDoctors.map((doctor) => doctor.dr_name);
        })
        .catch((error) => {
          console.log(error);
        });
    },
    addAppointment(appointmentData) {
      addAppointmentData(appointmentData)
        .then((response) => {
          console.log(response);
          this.$router.push({ name: "ShowAppointment" });
        })
        .catch((error) => {
          if (error.response.data.error.code === "ER_DUP_ENTRY") {
            alert(
              "This appointment slot is already booked. Please choose a different time."
            );
          } else {
            console.error("Error updating Appointment", error);
          }
        });
    },
  },
  computed: {
    doctorNameIsRequired() {
      return this.formValues.doctorName ? "" : "Please select Doctor";
    },
    dateIsRequired() {
      return this.formValues.appointmentDate ? "" : "Field is required";
    },
    timeIsRequired() {
      return this.formValues.appointmentTime ? "" : "Please select time";
    },
    specializationIsRequired() {
      return this.doctorSpecilization ? "" : "Field is required";
    },
  },
  watch: {
    "formValues.doctorName"(newDoctorId) {
      // Find the selected doctor object from availableDoctors array
      const selectedDoctor = this.availableDoctors.find(
        (doctor) => doctor.did === newDoctorId
      );
      // Update doctorSpec with the specification of the selected doctor
      this.doctorSpecilization = selectedDoctor ? selectedDoctor.specialization : "";
    },
  },
};
</script>

<style scoped></style>
