<template>
  <div>
    <mainHeader></mainHeader>

    <div class="w-screen flex flex-row pt-16">
      <div class="w-1/6">
        <navbar></navbar>
      </div>
      <div class="flex-grow pt-10">
        <div class="max-w-xxl mx-40">
          <div class="flex justify-end mb-5">
            <button
              @click="goBackShowPatient"
              class="bg-red-800 text-white font-bold py-2 px-5 rounded-md"
            >
              Go Back
            </button>
          </div>
          <form
            @submit.prevent="submitForm"
            class="bg-white border shadow-md shadow-red-800 rounded px-10 pb-2 mb-4 flex flex-wrap"
          >
            <div class="w-full flex justify-center py-3">
              <h2 class="text-3xl font-bold my-5 text-red-800">Add Patient</h2>
            </div>
            <div class="w-full md:w-1/2 px-3 mb-4">
              <label class="block text-sm font-bold pt-3 pb-1" for="name"> Name </label>
              <input
                class="shadow border rounded w-full py-2 px-3"
                id="name"
                type="text"
                placeholder="Enter Name"
                v-model.trim="formValues.name"
                maxlength="15"
                :class="{ 'border-red-500': nameIsRequired && isSubmit }"
              />
              <span v-if="isSubmit" class="text-red-500 text-sm">{{
                nameIsRequired
              }}</span>
              <label class="block text-sm font-bold pt-3 pb-1" for="dob">
                Date of Birth
              </label>
              <input
                class="shadow border rounded w-full py-2 px-3"
                id="dob"
                type="date"
                :max="maxDate"
                v-model="formValues.birthDate"
              />

              <label class="block text-sm font-bold pt-3 pb-1"> Gender </label>
              <div class="flex">
                <label class="inline-flex items-center mr-4">
                  <input
                    type="radio"
                    class="form-radio"
                    name="gender"
                    value="Male"
                    v-model="formValues.gender"
                  />
                  <span class="ml-2">Male</span>
                </label>
                <label class="inline-flex items-center">
                  <input
                    type="radio"
                    class="form-radio"
                    name="gender"
                    value="Female"
                    v-model="formValues.gender"
                  />
                  <span class="ml-2">Female</span>
                </label>
              </div>
              <span v-if="isSubmit" class="text-red-500 text-sm">{{
                genderIsRequired
              }}</span>
            </div>

            <div class="w-full md:w-1/2 px-3 mb-4">
              <label class="block text-sm font-bold pt-3 pb-1" for="mobNo">
                Mobile Number
              </label>
              <input
                class="shadow border rounded w-full py-2 px-3"
                id="mobNo"
                type="text"
                maxlength="10"
                placeholder="Enter Mobile Number"
                v-model="formValues.mobileNumber"
                :class="{ 'border-red-500': mobileIsRequired && isSubmit }"
              />
              <span v-if="isSubmit" class="text-red-500 text-sm">{{
                mobileIsRequired
              }}</span>
              <label class="block text-sm font-bold pt-3 pb-1" for="address">
                Address
              </label>
              <textarea
                class="shadow border rounded w-full px-3 h-11"
                id="address"
                placeholder="Enter Address"
                v-model="formValues.address"
                :class="{ 'border-red-500': addressIsRequired && isSubmit }"
              ></textarea>
              <span v-if="isSubmit" class="text-red-500 text-sm">{{
                addressIsRequired
              }}</span>
            </div>

            <div class="w-full flex justify-center">
              <button
                class="bg-red-800 text-white font-bold py-2 px-10 my-2 rounded"
                type="submit"
              >
                Add
              </button>
            </div>
          </form>
        </div>
      </div>
    </div>
  </div>
</template>

<script>
import navbar from "../components/shared/Navbar.vue";
import mainHeader from "../components/shared/MainHeader.vue";
import { addPatientData } from "../services/apiService.js";
import {
  isNameValid,
  isMobileValid,
  capitalizeEachWord,
} from "../services/userServices/fromValidationMethods.js";
export default {
  name: "AddPatient",
  components: { navbar, mainHeader },
  data() {
    return {
      formValues: {
        name: "",
        birthDate: "",
        mobileNumber: "",
        gender: "",
        address: "",
      },
      isSubmit: false,
      maxDate: new Date().toISOString().split("T")[0],
    };
  },
  methods: {
    goBackShowPatient() {
      this.$router.push({ name: "ShowPatient" });
    },
    submitForm() {
      this.isSubmit = true;
      if (
        !this.nameIsRequired &&
        !this.mobileIsRequired &&
        !this.addressIsRequired &&
        !this.genderIsRequired
      ) {
        console.log("FormValues: ", this.formValues);
        const patientData = {
          name: capitalizeEachWord(this.formValues.name),
          date_of_birth: this.formValues.birthDate || null,
          mobile_no: this.formValues.mobileNumber,
          gender: this.formValues.gender,
          address: capitalizeEachWord(this.formValues.address),
        };

        this.addPatient(patientData);
      }
    },

    // add patient data
    addPatient(patientData) {
      addPatientData(patientData)
        .then((response) => {
          console.log(response);
          this.$router.push({ name: "ShowPatient" });
        })
        .catch((error) => {
          if (
            error.response &&
            error.response.data &&
            error.response.data.error &&
            error.response.data.error.code === "ER_DUP_ENTRY"
          ) {
            // Check duplicate mobile number entry
            if (
              error.response.data.error.sqlMessage.includes("Duplicate entry") &&
              error.response.data.error.sqlMessage.includes("for key 'patient.mobile_no'")
            ) {
              alert("Mobile number already exists");
            }
          } else {
            console.log(error);
          }
        });
    },
  },
  computed: {
    nameIsRequired() {
      return this.formValues.name
        ? isNameValid(this.formValues.name)
        : "Field is required";
    },

    mobileIsRequired() {
      return this.formValues.mobileNumber
        ? isMobileValid(this.formValues.mobileNumber)
        : "Field is required";
    },

    addressIsRequired() {
      return this.formValues.address ? "" : "Field is required";
    },
    genderIsRequired() {
      return this.formValues.gender ? "" : "Please select gender";
    },
  },
};
</script>

<style scoped></style>
