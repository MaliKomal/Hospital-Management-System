<template>
  <div>
    <mainHeader></mainHeader>

    <div class="w-screen flex flex-row pt-16">
      <div class="w-1/6">
        <navbar></navbar>
      </div>
      <div class="flex-grow pt-10">
        <div class="max-w-xxl mx-40">
          <div class="flex justify-end mb-5">
            <button
              @click="goBackShowPatient"
              class="bg-red-800 text-white font-bold py-2 px-5 rounded-md"
            >
              Go Back
            </button>
          </div>
          <form
            @submit.prevent="updatePatient"
            class="bg-white border shadow-md shadow-red-800 rounded px-10 pb-2 mb-4 flex flex-wrap"
          >
            <div class="w-full flex justify-center py-3">
              <h2 class="text-3xl font-bold my-5 text-red-800">Update Patient</h2>
            </div>
            <div class="w-full md:w-1/2 px-3 mb-4">
              <label class="block text-sm font-bold pt-3 pb-1" for="name"> Name </label>
              <input
                class="shadow border rounded w-full py-2 px-3"
                id="name"
                type="text"
                placeholder="Enter Name"
                v-model.trim="formValues.name"
                :class="{ 'border-red-500': nameIsRequired && isUpdate }"
              />
              <span v-if="isUpdate" class="text-red-500 text-sm">{{
                nameIsRequired
              }}</span>
              <label class="block text-sm font-bold pt-3 pb-1" for="dob">
                Date of Birth
              </label>
              <input
                class="shadow border rounded w-full py-2 px-3"
                id="dob"
                type="date"
                :max="maxDate"
                v-model="formValues.birthDate"
              />

              <label class="block text-sm font-bold pt-3 pb-1"> Gender </label>
              <div class="flex">
                <label class="inline-flex items-center mr-4">
                  <input
                    type="radio"
                    class="form-radio"
                    name="gender"
                    value="male"
                    v-model="formValues.gender"
                  />
                  <span class="ml-2">Male</span>
                </label>
                <label class="inline-flex items-center">
                  <input
                    type="radio"
                    class="form-radio"
                    name="gender"
                    value="female"
                    v-model="formValues.gender"
                  />
                  <span class="ml-2">Female</span>
                </label>
              </div>
              <span v-if="isUpdate" class="text-red-500 text-sm">{{
                mobileIsRequired
              }}</span>
            </div>

            <div class="w-full md:w-1/2 px-3 mb-4">
              <label class="block text-sm font-bold pt-3 pb-1" for="mobNo">
                Mobile Number
              </label>
              <input
                class="shadow border rounded w-full py-2 px-3"
                id="mobNo"
                type="text"
                placeholder="Enter Mobile Number"
                v-model="formValues.mobileNumber"
                maxlength="10"
                :class="{ 'border-red-500': mobileIsRequired && isUpdate }"
              />
              <span v-if="isUpdate" class="text-red-500 text-sm">{{
                mobileIsRequired
              }}</span>
              <label class="block text-sm font-bold pt-3 pb-1" for="address">
                Address
              </label>
              <textarea
                class="shadow border rounded w-full px-3 h-10"
                id="address"
                placeholder="Enter Address"
                v-model.trim="formValues.address"
                :class="{ 'border-red-500': addressIsRequired && isUpdate }"
              ></textarea>
              <span v-if="isUpdate" class="text-red-500 text-sm">{{
                addressIsRequired
              }}</span>
            </div>

            <div class="w-full flex justify-center">
              <button
                class="bg-red-800 text-white font-bold py-2 px-10 my-2 rounded"
                type="submit"
              >
                Update
              </button>
            </div>
          </form>
        </div>
      </div>
    </div>
  </div>
</template>

<script>
import navbar from "../components/shared/Navbar.vue";
import mainHeader from "../components/shared/MainHeader.vue";
import { getPatientDataById, updatePatientData } from "../services/apiService.js";
import {
  isNameValid,
  isMobileValid,
  capitalizeEachWord,
} from "../services/userServices/fromValidationMethods.js";
export default {
  name: "UpdatePatient",
  components: { navbar, mainHeader },

  data() {
    return {
      formValues: {
        name: "",
        birthDate: "",
        mobileNumber: "",
        gender: "",
        address: "",
      },
      isUpdate: false,
      patientId: null,
      maxDate: new Date().toISOString().split("T")[0],
    };
  },

  mounted() {
    this.patientId = this.$route.query?.patientIds;
    this.getDataById();
  },
  methods: {
    goBackShowPatient() {
      this.$router.push({ name: "ShowPatient" });
    },
    // get data by id and reverse bind to form values
    getDataById() {
      getPatientDataById(this.patientId)
        .then((response) => {
          console.log(response.data);
          this.formValues.name = response.data[0].name;
          this.formValues.address = response.data[0].address;
          this.formValues.gender = response.data[0].gender;
          this.formValues.mobileNumber = response.data[0].mobile_no;
          if (response.data[0].date_of_birth) {
            const serverDate = new Date(response.data[0].date_of_birth);
            const clientDate = new Date(
              serverDate.getTime() - serverDate.getTimezoneOffset() * 60000
            );
            this.formValues.birthDate = clientDate.toISOString().split("T")[0];
          } else {
            this.formValues.birthDate = null;
          }
        })
        .catch((error) => {
          console.log(error);
        });
    },
    // form submit
    updatePatient() {
      this.isUpdate = true;
      if (
        !this.nameIsRequired &&
        !this.mobileIsRequired &&
        !this.addressIsRequired &&
        !this.genderIsRequired
      ) {
        console.log("Form values", this.formValues);
        const updatedData = {
          name: capitalizeEachWord(this.formValues.name),
          date_of_birth: this.formValues.birthDate || null,
          mobile_no: this.formValues.mobileNumber,
          gender: this.formValues.gender,
          address: capitalizeEachWord(this.formValues.address),
        };
        this.updateDataOfPatient(updatedData);
      }
    },
    updateDataOfPatient(updatedData) {
      updatePatientData(this.patientId, updatedData)
        .then((response) => {
          console.log("Patient updated successfully", response);
          this.$router.push({ name: "ShowPatient" });
        })
        .catch((error) => {
          if (
            error.response &&
            error.response.data &&
            error.response.data.error &&
            error.response.data.error.code === "ER_DUP_ENTRY"
          ) {
            // Check duplicate mobile number entry
            if (
              error.response.data.error.sqlMessage.includes("Duplicate entry") &&
              error.response.data.error.sqlMessage.includes("for key 'patient.mobile_no'")
            ) {
              alert("Mobile number already exists");
            }
          } else {
            console.log(error);
          }
        });
    },
  },
  computed: {
    nameIsRequired() {
      return this.formValues.name
        ? isNameValid(this.formValues.name)
        : "Field is required";
    },

    mobileIsRequired() {
      return this.formValues.mobileNumber
        ? isMobileValid(this.formValues.mobileNumber)
        : "Field is required";
    },

    addressIsRequired() {
      return this.formValues.address ? "" : "Field is required";
    },
    genderIsRequired() {
      return this.formValues.gender ? "" : "Please select gender";
    },
  },
};
</script>

<style scoped></style>
