<template>
  <div>
    <mainHeader></mainHeader>

    <div class="w-screen flex flex-row pt-16">
      <div class="w-1/6">
        <navbar></navbar>
      </div>
      <div class="flex-grow pt-10">
        <div class="max-w-md mx-auto">
          <div class="flex justify-end mb-5">
            <button
              @click="goBackShowBilling"
              class="bg-red-800 text-white font-bold py-1 px-3 rounded-md"
            >
              Go Back
            </button>
          </div>
          <form
            @submit.prevent="submitForm"
            class="bg-white border shadow-md shadow-red-800 rounded px-8 pt-6 pb-8 mb-4"
          >
            <h2 class="text-3xl font-bold my-5 text-center text-red-800">Add Billing</h2>
            <div class="mb-4">
              <label class="block text-sm font-bold mb-2" for="amount"> Amount </label>
              <input
                class="shadow border rounded w-full py-2 px-3 bg-slate-200"
                id="amount"
                type="text"
                readonly
                v-model="formValues.amount"
              />
            </div>
            <div class="mb-4">
              <label class="block text-sm font-bold mb-2" for="dob">Billing Date </label>
              <input
                class="shadow border rounded w-full py-2 px-3 bg-slate-200"
                id="dob"
                type="date"
                v-model="formValues.billingDate"
                readonly
              />
            </div>

            <div class="mb-4">
              <label class="block text-sm font-bold mb-2" for="pname">
                Patient Name</label
              >
              <input
                class="shadow border rounded w-full py-2 px-3 bg-slate-200"
                id="pname"
                type="text"
                readonly
                v-model="formValues.patientName"
              />
            </div>
            <div class="mb-4">
              <label class="block text-sm font-bold mb-2" for="dName">
                Doctor Name
              </label>
              <input
                class="shadow border rounded w-full py-2 px-3 bg-slate-200"
                id="dName"
                type="text"
                readonly
                v-model="formValues.doctorName"
              />
            </div>

            <div class="flex items-center justify-center">
              <button
                v-if="appointmentStatus === 'completed'"
                class="bg-red-800 text-white font-bold py-2 px-10 mt-4 rounded"
                type="submit"
              >
                Mark as Paid
              </button>
            </div>
          </form>
        </div>
      </div>
    </div>
  </div>
</template>

<script>
import navbar from "../components/shared/Navbar.vue";
import mainHeader from "../components/shared/MainHeader.vue";
import { addBillingData, getAppointmentData } from "../services/apiService.js";
export default {
  name: "AddBilling",
  components: { navbar, mainHeader },
  data() {
    return {
      formValues: {
        amount: "",
        billingDate: "",
        patientName: "",
        doctorName: "",
      },
      appointId: null,
      appointmentData: [],
      isSubmit: false,
      appointmentStatus: "",

      // maxDate: new Date().toISOString().split("T")[0],
    };
  },

  mounted() {
    this.getData();
    this.appointId = this.$route.query?.appointmentId;
    console.log(this.appointId);
  },
  methods: {
    goBackShowBilling() {
      this.$router.push({ name: "ShowBilling" });
    },

    //function to get appointmnet data
    getData() {
      getAppointmentData()
        .then((response) => {
          // Filter appointment data based on the appointment ID
          const appId = this.appointId;
          this.appointmentData = response.data.filter(
            (appointment) => appointment.app_id == appId
          );

          this.appointmentStatus = this.appointmentData[0].status;
          this.formValues.amount = this.appointmentData[0].doctor_fees;
          const serverDate = new Date(this.appointmentData[0].appointment_date);
          const clientDate = new Date(
            serverDate.getTime() - serverDate.getTimezoneOffset() * 60000
          );
          this.formValues.billingDate = clientDate.toISOString().split("T")[0];

          this.formValues.patientName = this.appointmentData[0].patient_name;
          this.formValues.doctorName = this.appointmentData[0].doctor_name;
        })
        .catch((error) => {
          console.log(error);
        })
        .finally(() => {
          this.loading = false;
        });
    },
    submitForm() {
      this.isSubmit = true;
      console.log("FormValues: ", this.formValues);
      const billingData = {
        amount: this.formValues.amount,
        billing_date: this.formValues.billingDate,
        patient_name: this.formValues.patientName,
        dr_fees: this.formValues.doctorFees,
        doctor_name: this.formValues.doctorName,
        app_id: this.appointId,
      };

      this.addBilling(billingData);
    },
    addBilling(billingData) {
      addBillingData(billingData)
        .then((response) => {
          console.log(response);
          this.$router.push({ name: "ShowBilling" });
        })
        .catch((error) => {
          if (error.response.data.error.code === "ER_DUP_ENTRY") {
            alert("You are alrady paid bill");
            this.$router.push({ name: "ShowBilling" });
          } else {
            console.error("Error updating Appointment", error);
          }
        });
    },
  },
};
</script>

<style scoped></style>
