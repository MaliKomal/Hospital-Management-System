<template>
  <div>
    <mainHeader></mainHeader>

    <div class="w-screen flex flex-row pt-16">
      <div class="w-1/6">
        <navbar></navbar>
      </div>
      <!-- Container for the main content -->
      <div class="flex-grow mx-5 pt-1 mt-10">
        <div v-if="loading" class="flex flex-col justify-center items-center my-20">
          <svg
            class="w-16 h-16 text-gray-300 animate-spin"
            viewBox="0 0 64 64"
            fill="none"
            xmlns="http://www.w3.org/2000/svg"
            width="30"
            height="30"
          >
            <path
              d="M32 3C35.8083 3 39.5794 3.75011 43.0978 5.20749C46.6163 6.66488 49.8132 8.80101 52.5061 11.4939C55.199 14.1868 57.3351 17.3837 58.7925 20.9022C60.2499 24.4206 61 28.1917 61 32C61 35.8083 60.2499 39.5794 58.7925 43.0978C57.3351 46.6163 55.199 49.8132 52.5061 52.5061C49.8132 55.199 46.6163 57.3351 43.0978 58.7925C39.5794 60.2499 35.8083 61 32 61C28.1917 61 24.4206 60.2499 20.9022 58.7925C17.3837 57.3351 14.1868 55.199 11.4939 52.5061C8.801 49.8132 6.66487 46.6163 5.20749 43.0978C3.7501 39.5794 3 35.8083 3 32C3 28.1917 3.75011 24.4206 5.2075 20.9022C6.66489 17.3837 8.80101 14.1868 11.4939 11.4939C14.1868 8.80099 17.3838 6.66487 20.9022 5.20749C24.4206 3.7501 28.1917 3 32 3L32 3Z"
              stroke="currentColor"
              stroke-width="6"
              stroke-linecap="round"
              stroke-linejoin="round"
            ></path>
            <path
              d="M32 3C36.5778 3 41.0906 4.08374 45.1692 6.16256C49.2477 8.24138 52.7762 11.2562 55.466 14.9605C58.1558 18.6647 59.9304 22.9531 60.6448 27.4748C61.3591 31.9965 60.9928 36.6232 59.5759 40.9762"
              stroke="currentColor"
              stroke-width="6"
              stroke-linecap="round"
              stroke-linejoin="round"
              class="text-red-900"
            ></path>
          </svg>
          <p class="text-2xl font-bold text-red-800 mt-5">Appointment Record Loading</p>
        </div>
        <div v-else>
          <!-- Container for the heading and button -->

          <div class="flex flex-col justify-center mx-10">
            <div class="flex justify-between my-5">
              <!-- Heading -->
              <h2 class="text-2xl font-bold">Appointment Details</h2>
              <!-- Button for adding a patient record -->
              <!-- <button
                @click="addAppointment"
                class="bg-red-800 text-white font-bold py-2 px-4 rounded-md"
              >
                Add Appointment
              </button> -->
            </div>
            <table v-if="formattedAppointmentData.length > 0">
              <tr>
                <th class="px-3 py-3 bg-gray-50 border border-black">Id</th>
                <th class="px-3 py-3 bg-gray-50 border border-black">Patient Name</th>
                <th class="px-3 py-3 bg-gray-50 border border-black">Doctor Name</th>
                <th class="px-3 py-3 bg-gray-50 border border-black">Specialization</th>
                <th class="px-3 py-3 bg-gray-50 border border-black">Appointment Date</th>
                <th class="px-3 py-3 bg-gray-50 border border-black">Appointment Time</th>

                <th class="px-3 py-3 bg-gray-50 border border-black">Status</th>
                <th class="px-3 py-3 bg-gray-50 border border-black">Actions</th>
              </tr>

              <tr v-for="data in formattedAppointmentData">
                <td class="px-6 py-4 border border-black text-right">
                  {{ data.app_id }}
                </td>
                <td class="px-3 py-2 border border-black">{{ data.patient_name }}</td>
                <td class="px-3 py-2 border border-black">{{ data.doctor_name }}</td>
                <td class="px-3 py-2 border border-black">
                  {{ data.dr_specialization }}
                </td>
                <td class="px-3 py-2 border border-black">{{ data.appointment_date }}</td>
                <td class="px-3 py-2 border border-black">{{ data.appointment_time }}</td>

                <td class="px-3 py-2 border border-black">{{ data.status }}</td>

                <td class="px-3 py-2 border border-black w-50 text-center">
                  <button
                    @click="updateRecord(data.app_id)"
                    class="bg-red-800 text-white font-bold py-2 px-6 rounded-xl mr-2"
                    :disabled="data.status === 'completed'"
                    :class="{
                      'opacity-50 cursor-not-allowed': data.status === 'completed',
                    }"
                  >
                    Edit
                  </button>
                  <button
                    @click="showBill(data.app_id)"
                    class="bg-red-800 text-white font-bold py-2 px-6 rounded-xl mr-2"
                  >
                    Show Bill
                  </button>
                </td>
              </tr>
            </table>
            <!-- no data in patient array  -->
            <div
              v-else
              class="border-dashed border-2 border-gray-400 p-20 text-2xl font-bold text-red-800 text-center"
            >
              No Data Available
            </div>
          </div>
        </div>
      </div>
    </div>
  </div>
</template>

<script>
import navbar from "../components/shared/Navbar.vue";
import mainHeader from "../components/shared/MainHeader.vue";
import deletePopup from "../components/shared/DeletePopup.vue";
import { getAppointmentData } from "../services/apiService.js";

export default {
  name: "ShowAppointment",
  components: { navbar, mainHeader, deletePopup },
  data() {
    return {
      appointmentData: [],
      deleteId: null,
      loading: false,
      patientName: "",
    };
  },
  mounted() {
    this.getData();
  },
  methods: {
    // function to update patient record
    updateRecord(appointmentDataId) {
      this.$router.push({
        name: "UpdateAppointment",
        query: { aptIds: appointmentDataId },
      });
    },
    //funtion to add new Doctor record
    addAppointment() {
      this.$router.push({ name: "AddAppointment" });
    },
    //function to get appointmnet data
    getData() {
      this.loading = true;
      getAppointmentData()
        .then((response) => {
          // console.log(response.data);
          this.appointmentData = response.data;
        })
        .catch((error) => {
          console.log(error);
        })
        .finally(() => {
          this.loading = false;
        });
    },
    // function to add bill

    showBill(id) {
      this.$router.push({
        name: "AddBilling",
        query: { appointmentId: id },
      });
    },
    //function to show popup and delete data

    // Function to format date
    formatDate(dateString) {
      const date = new Date(dateString);
      const timeZoneOffset = date.getTimezoneOffset() * 60000; // Convert minutes to milliseconds
      const adjustedDate = new Date(date.getTime() - timeZoneOffset);

      return adjustedDate.toISOString().split("T")[0];
    },
  },
  computed: {
    formattedAppointmentData() {
      return this.appointmentData.map((data) => ({
        ...data,
        appointment_date: this.formatDate(data.appointment_date),
      }));
    },
  },
};
</script>

<style scoped></style>
