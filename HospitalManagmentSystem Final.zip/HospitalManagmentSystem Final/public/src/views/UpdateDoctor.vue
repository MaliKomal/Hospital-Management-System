<template>
  <div>
    <mainHeader></mainHeader>

    <div class="w-screen flex flex-row pt-16">
      <div class="w-1/6">
        <navbar></navbar>
      </div>
      <div class="flex-grow pt-5">
        <div class="max-w-xl mx-auto">
          <div class="flex justify-end mb-5">
            <button
              @click="goBackShowDaoctor"
              class="bg-red-800 text-white font-bold py-1 px-4 rounded-md"
            >
              Go Back
            </button>
          </div>
          <form
            @submit.prevent="updateDoctor"
            class="border shadow-md shadow-red-800 rounded px-8 mb-5"
          >
            <h2 class="text-3xl font-bold my-5 text-center text-red-800">
              Update Doctor
            </h2>
            <div class="mb-4">
              <label class="block text-sm font-bold mb-2" for="name"> Name </label>
              <input
                class="shadow border rounded w-full py-2 px-3"
                id="name"
                type="text"
                placeholder="Enter Name"
                maxlength="15"
                v-model.trim="formValues.name"
                :class="{ 'border-red-500': nameIsRequired && isUpdate }"
              />
              <span v-if="isUpdate" class="text-red-500 text-sm">{{
                nameIsRequired
              }}</span>
            </div>
            <div class="mb-4">
              <label class="block text-sm font-bold mb-2" for="specialization">
                Specialization
              </label>

              <select
                class="shadow border rounded w-full py-2 px-3 text-gray-700"
                id="specialization"
                v-model="formValues.specialization"
              
              >
                <option value="" disabled>Select Specialization</option>
                <option
                  v-for="specialization in doctorSpecialization"
                  :value="specialization"
                >
                  {{ specialization }}
                </option>
              </select>
            
            </div>
            <div class="mb-2">
              <label class="block text-sm font-bold mb-2" for="mobNo">
                Mobile Number
              </label>
              <input
                class="shadow border rounded w-full py-2 px-3"
                id="mobNo"
                type="text"
                maxlength="10"
                placeholder="Enter Mobile Number"
                v-model="formValues.mobileNumber"
                :class="{ 'border-red-500': mobileIsRequired && isUpdate }"
              />
              <span v-if="isUpdate" class="text-red-500 text-sm">{{
                mobileIsRequired
              }}</span>
            </div>
            <div class="mb-2">
              <label class="block text-sm font-bold mb-2" for="email"> Email </label>
              <input
                class="shadow border rounded w-full py-2 px-3"
                id="email"
                type="text"
                maxlength="30"
                placeholder="Enter Email"
                v-model="formValues.email"
                :class="{ 'border-red-500': emailIsRequird && isUpdate }"
              />
              <span v-if="isUpdate" class="text-red-500 text-sm">{{
                emailIsRequird
              }}</span>
            </div>

            <div class="mb-2 flex flex-wrap">
              <div class="w-full md:w-1/2 px-3 mb-4">
                <label class="block text-sm font-bold mb-4"> Doctor Status</label>
                <div class="flex">
                  <label class="inline-flex items-center mr-4">
                    <input
                      type="radio"
                      class="form-radio"
                      name="status"
                      value="Available"
                      v-model="formValues.doctorStatus"
                    />
                    <span class="ml-2">Available</span>
                  </label>
                  <label class="inline-flex items-center">
                    <input
                      type="radio"
                      class="form-radio"
                      name="status"
                      value="Unavailable"
                      v-model="formValues.doctorStatus"
                    />
                    <span class="ml-2">Unavailable</span>
                  </label>
                </div>
               
              </div>
              <div class="w-full md:w-1/2 px-3 mb-4">
                <label class="block text-sm font-bold mb-2" for="fees">
                  Doctor Fees
                </label>
                <input
                  class="shadow border rounded w-full py-2 px-3"
                  id="fees"
                  type="text"
                  maxlength="10"
                  placeholder="Enter Doctor Fees"
                  v-model="formValues.doctorFees"
                  :class="{ 'border-red-500': doctorFeesRequired && isUpdate }"
                />
                <span v-if="isUpdate" class="text-red-500 text-sm">{{
                  doctorFeesRequired
                }}</span>
              </div>
            </div>
            <div class="flex items-center justify-center">
              <button
                class="bg-red-800 text-white font-bold py-2 px-10 my-5 rounded"
                type="submit"
              >
                Update
              </button>
            </div>
          </form>
        </div>
      </div>
    </div>
  </div>
</template>

<script>
import navbar from "../components/shared/Navbar.vue";
import mainHeader from "../components/shared/MainHeader.vue";
import { getDoctorDataById, updateDoctorData } from "../services/apiService.js";
import {
  isEmailValid,
  isNameValid,
  isMobileValid,
  capitalizeEachWord,
} from "../services/userServices/fromValidationMethods.js";
export default {
  name: "UpdateDoctor",
  components: { navbar, mainHeader },
  data() {
    return {
      formValues: {
        name: "",
        specialization: "",
        mobileNumber: "",
        email: "",
        doctorStatus: "",
        doctorFees: "",
      },
      doctorSpecialization: [
        "Cardiologists",
        "Dentists",
        "Surgeons",
        "Seurologists",
        "Psychiatrists",
      ],
      doctorId: null,
      isUpdate: false,
    };
  },
  mounted() {
    this.doctorId = this.$route.query?.doctorIds;
    this.getDataById();
  },
  methods: {
    goBackShowDaoctor() {
      this.$router.push({ name: "ShowDoctor" });
    },
    // get data by id and reverse bind to form values
    getDataById() {
      getDoctorDataById(this.doctorId)
        .then((response) => {
          console.log(response.data);
          this.formValues.name = response.data[0].dr_name;
          this.formValues.specialization = response.data[0].specialization;
          this.formValues.mobileNumber = response.data[0].mobile_no;
          this.formValues.email = response.data[0].email;
          this.formValues.doctorStatus = response.data[0].dr_status;
          this.formValues.doctorFees = response.data[0].fees;
        })
        .catch((error) => {
          console.log(error);
        });
    },
    // form submit
    updateDoctor() {
      this.isUpdate = true;
      if (
        !this.nameIsRequired &&
        !this.mobileIsRequired &&
        !this.emailIsRequird &&
        
        !this.doctorFeesRequired
      ) {
        console.log("Form values", this.formValues);
        const updatedData = {
          dr_name: capitalizeEachWord(this.formValues.name),
          specialization: this.formValues.specialization,
          mobile_no: this.formValues.mobileNumber,
          email: this.formValues.email,
          dr_status: this.formValues.doctorStatus,
          fees: this.formValues.doctorFees,
        };
        this.updateDataOfDoctor(updatedData);
      }
    },
    updateDataOfDoctor(updatedData) {
      updateDoctorData(this.doctorId, updatedData)
        .then((response) => {
          console.log("Doctor updated successfully", response);
          this.$router.push({ name: "ShowDoctor" });
        })
        .catch((error) => {
          if (
            error.response &&
            error.response.data &&
            error.response.data.error &&
            error.response.data.error.code === "ER_DUP_ENTRY"
          ) {
            // Check  duplicate email entry
            if (
              error.response.data.error.sqlMessage.includes("Duplicate entry") &&
              error.response.data.error.sqlMessage.includes("for key 'doctor.email'")
            ) {
              alert("Email already exists");
            }
            // Check duplicate mobile number entry
            else if (
              error.response.data.error.sqlMessage.includes("Duplicate entry") &&
              error.response.data.error.sqlMessage.includes("for key 'doctor.mobile_no'")
            ) {
              alert("Mobile number already exists");
            }
          } else {
            console.log(error);
          }
        });
    },
  },
  computed: {
    nameIsRequired() {
      return this.formValues.name
        ? isNameValid(this.formValues.name)
        : "Field is required";
    },

    mobileIsRequired() {
      return this.formValues.mobileNumber
        ? isMobileValid(this.formValues.mobileNumber)
        : "Field is required";
    },
    emailIsRequird() {
      return this.formValues.email
        ? isEmailValid(this.formValues.email)
        : "Email is required";
    },

    doctorFeesRequired() {
      return this.formValues.doctorFees ? "" : "Field is required";
    },
  },
};
</script>

<style scoped></style>
