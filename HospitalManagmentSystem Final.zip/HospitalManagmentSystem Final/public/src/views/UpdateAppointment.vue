<template>
  <div>
    <mainHeader></mainHeader>

    <div class="w-screen flex flex-row pt-16">
      <div class="w-1/6">
        <navbar></navbar>
      </div>
      <div class="flex-grow pt-10">
        <div class="max-w-xxl mx-40">
          <div class="flex justify-end mb-5">
            <button
              @click="goBackShowAppointment"
              class="bg-red-800 text-white font-bold py-1 px-3 rounded-md"
            >
              Go Back
            </button>
          </div>
          <form
            @submit.prevent="updateAppointment"
            class="bg-white border shadow-md shadow-red-800 rounded px-10 pb-2 mb-4 flex flex-wrap"
          >
            <div class="w-full flex justify-center py-3">
              <h2 class="text-3xl font-bold my-5 text-red-800">Update Appointment</h2>
            </div>

            <div class="w-full md:w-1/2 px-3 mb-4">
              <label class="block text-sm font-bold mb-2" for="pName">
                Patient Name
              </label>
              <input
                class="shadow border bg-slate-200 rounded w-full py-2 px-3"
                id="pName"
                disabled
                type="text"
                v-model="formValues.patientName"
              />
              <!--  -->
              <label class="block text-sm font-bold pt-3 pb-1" for="dName">
                Doctor Name
              </label>
              <select
                id="dName"
                class="shadow border rounded w-full py-2 px-3 text-gray-700"
                v-model="formValues.doctorId"
              >
                <option value="" disabled>Select</option>
                <option v-for="doctor in availableDoctors" :value="doctor.did">
                  {{ doctor.dr_name }}
                </option>
              </select>

              <!-- doctor specilization -->
              <label class="block text-sm font-bold mb-2" for="doctorSpec">
                Doctor Specification
              </label>
              <input
                class="shadow border rounded w-full py-2 px-3"
                id="doctorSpec"
                type="text"
                v-model="formValues.doctorSpecilization"
                readonly
              />
            </div>

            <div class="w-full md:w-1/2 px-3 mb-4">
              <label class="block text-sm font-bold mb-2" for="dob"
                >Appointment Date
              </label>
              <input
                class="shadow border rounded w-full py-2 px-3"
                id="dob"
                type="date"
                :min="minDate"
                :max="maxDate"
                v-model="formValues.appointmentDate"
                :class="{ 'border-red-500': dateIsRequired && isUpdate }"
              />
              <span v-if="isUpdate" class="text-red-500 text-sm">{{
                dateIsRequired
              }}</span>
              <label class="block text-sm font-bold mb-2" for="specialization">
                Appointment Time
              </label>

              <select
                class="shadow border rounded w-full py-2 px-3 text-gray-700"
                id="specialization"
                v-model="formValues.appointmentTime"
              >
                <option value="" disabled>Select Time</option>
                <option v-for="time in timeSlots" :value="time">
                  {{ time }}
                </option>
              </select>

              <!-- appintment status -->
              <label class="block text-sm font-bold mb-2"> Appointment Status</label>
              <div class="flex">
                <label class="inline-flex items-center mr-4">
                  <input
                    type="radio"
                    class="form-radio"
                    name="status"
                    value="scheduled"
                    v-model="formValues.appointmentStatus"
                  />
                  <span class="ml-2">Scheduled</span>
                </label>
                <label class="inline-flex items-center mr-4">
                  <input
                    type="radio"
                    class="form-radio"
                    name="status"
                    value="canceled"
                    v-model="formValues.appointmentStatus"
                  />
                  <span class="ml-2">Canceled</span>
                </label>
                <label class="inline-flex items-center">
                  <input
                    type="radio"
                    class="form-radio"
                    name="status"
                    value="completed"
                    v-model="formValues.appointmentStatus"
                  />
                  <span class="ml-2">Completed</span>
                </label>
              </div>
            </div>
            <div class="w-full flex justify-center">
              <button
                class="bg-red-800 text-white font-bold py-2 px-10 my-2 rounded"
                type="submit"
              >
                Update
              </button>
            </div>
          </form>
        </div>
      </div>
    </div>
  </div>
</template>

<script>
import navbar from "../components/shared/Navbar.vue";
import mainHeader from "../components/shared/MainHeader.vue";
import {
  getAppointmentDataById,
  updateAppointmentData,
  getDoctorData,
} from "../services/apiService.js";

export default {
  name: "UpdateAppointment",
  components: { navbar, mainHeader },
  data() {
    return {
      formValues: {
        appointmentDate: "",
        appointmentStatus: "",
        patientName: "",
        doctorId: null,
        appointmentTime: "",
        doctorSpecilization: "",
      },
      timeSlots: [
        "10am to 11am",
        "11am to 12am",
        "12am to 1pm ",
        "1pm to 2pm",
        "3pm to 4pm",
        "4pm to 5pm",
      ],
      appointmentId: null,
      isUpdate: false,
      doctorStatus: 1,
      availableDoctors: [],
      selecteDoctorName: "",

      // set min and max date to appointment date
      minDate: new Date().toISOString().split("T")[0],
      maxDate: new Date(new Date().getTime() + 8 * 24 * 60 * 60 * 1000)
        .toISOString()
        .split("T")[0],
    };
  },
  mounted() {
    this.appointmentId = this.$route.query?.aptIds;
    this.getDataById();
    this.getData();
  },
  methods: {
    goBackShowAppointment() {
      this.$router.push({ name: "ShowAppointment" });
    },
    // get data by id and reverse bind to form values
    getDataById() {
      getAppointmentDataById(this.appointmentId)
        .then((response) => {
          console.log("", response.data);
          this.formValues.appointmentStatus = response.data[0].status;
          this.formValues.patientName = response.data[0].patient_name;
          this.selecteDoctorName = response.data[0].doctor_name;
          console.log("name", this.selecteDoctorName);

          this.formValues.appointmentTime = response.data[0].appointment_time;
          this.formValues.doctorSpecilization = response.data[0].dr_specialization;
          console.log(this.formValues.doctorSpecilization);
          const serverDate = new Date(response.data[0].appointment_date);
          const clientDate = new Date(
            serverDate.getTime() - serverDate.getTimezoneOffset() * 60000
          );
          this.formValues.appointmentDate = clientDate.toISOString().split("T")[0];
        })
        .catch((error) => {
          console.log(error);
        });
    },
    //function to get doctor record
    getData() {
      getDoctorData(this.doctorStatus)
        .then((response) => {
          this.availableDoctors = response.data.filter(
            (doctor) => doctor.dr_status === "Available"
          );
          // console.log("response is here..", this.availableDoctors);

          // Find the doctor id by name
          const doctor = this.availableDoctors.find(
            (doctor) => doctor.dr_name === this.selecteDoctorName
          );

          if (doctor) {
            this.formValues.doctorId = doctor.did;
            // console.log("I found ID..", this.doctorId);
          } else {
            console.log("Doctor not found.");
            return null;
          }
        })
        .catch((error) => {
          console.log(error);
        });
    },
    updateAppointment() {
      this.isUpdate = true;
      if (this.formValues.doctorId) {
        console.log("Form values", this.formValues);
        const updatedData = {
          appointment_date: this.formValues.appointmentDate,
          status: this.formValues.appointmentStatus,
          doctor_id: this.formValues.doctorId,
          appointment_time: this.formValues.appointmentTime,
          dr_specialization: this.formValues.doctorSpecilization,
        };
        this.updateDataOfAppointment(updatedData);
      } else {
        // Display error message when no doctor is selected
        this.errorMessage = "Please select a Doctor";
      }
    },
    updateDataOfAppointment(updatedData) {
      updateAppointmentData(this.appointmentId, updatedData)
        .then((response) => {
          console.log("Appointment updated successfully", response);
          this.$router.push({ name: "ShowAppointment" });
        })
        .catch((error) => {
          if (error.response.data.error.code === "ER_DUP_ENTRY") {
            alert(
              "This appointment slot is already booked. Please choose a different time."
            );
          } else {
            console.error("Error updating Appointment", error);
          }
        });
    },
  },
  computed: {
    dateIsRequired() {
      return this.formValues.appointmentDate ? "" : "Field is required";
    },
  },
  // watch on select doctor acording to that add apecilization
  watch: {
    "formValues.doctorId"(newDoctorId) {
      // Find the selected doctor object from availableDoctors array
      const selectedDoctor = this.availableDoctors.find(
        (doctor) => doctor.did === newDoctorId
      );
      // Update doctorSpec with the specification of the selected doctor
      this.formValues.doctorSpecilization = selectedDoctor
        ? selectedDoctor.specialization
        : "";
    },
  },
};
</script>

<style scoped></style>
