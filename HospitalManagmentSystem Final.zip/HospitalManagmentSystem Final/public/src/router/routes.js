import { createWebHistory, createRouter } from "vue-router";

const routes = [
  {
    name: "Login",
    path: "/login",
    component: () => import("../views/Login.vue"),
  },
 
  {
    name: "ShowPatient",
    path: "/showPatient",
    component: () => import("../views/ShowPatient.vue"),
    meta:{requiresAuth:true}
  },
  
  {
    name: "AddPatient",
    path: "/addPatient",
    component: () => import("../views/AddPatient.vue"),
    meta:{requiresAuth:true}
  },
  {
    name: "UpdatePatient",
    path: "/updatePatient",
    component: () => import("../views/UpdatePatient.vue"),
    meta:{requiresAuth:true}
  },
  // Doctor routes
  {
    name: "ShowDoctor",
    path: "/showDoctor",
    component: () => import("../views/ShowDoctor.vue"),
    meta:{requiresAuth:true}
  },
  {
    name: "AddDoctor",
    path: "/addDoctor",
    component: () => import("../views/AddDoctor.vue"),
    meta:{requiresAuth:true}
  },
  {
    name: "UpdateDoctor",
    path: "/updateDoctor",
    component: () => import("../views/UpdateDoctor.vue"),
    meta:{requiresAuth:true}
  },
  // Appointment routes
  {
    name: "ShowAppointment",
    path: "/showAppointment",
    component: () => import("../views/ShowAppointment.vue"),
    meta:{requiresAuth:true}
  },
  {
    name: "AddAppointment",
    path: "/addAppointment",
    component: () => import("../views/AddAppointment.vue"),
    meta:{requiresAuth:true}
  },
  {
    name: "UpdateAppointment",
    path: "/updateAppointment",
    component: () => import("../views/UpdateAppointment.vue"),
    meta:{requiresAuth:true}
  },
  {
    name: "ShowBilling",
    path: "/showBilling",
    component: () => import("../views/ShowBilling.vue"),
    meta:{requiresAuth:true}
  },
  {
    name: "AddBilling",
    path: "/addBilling",
    component: () => import("../views/AddBilling.vue"),
    meta:{requiresAuth:true}
  },
 
 
];


const router = createRouter({
  history: createWebHistory(),
  routes,
});

router.beforeEach((to, from, next) => {
  
  // check if the route requires authentication
  if (to.meta.requiresAuth) {
      if (localStorage.getItem('token')) {
          next();
      } else {
             next('/login');
      }
  } else {
       next();
  }
});


export default router;
