<template>
  <div
    class="fixed top-0 w-screen flex items-center justify-between px-4 border-2 bg-white border-red-800 shadow-lg"
  >
    <!-- src="../assets/images/logo2.png" -->
    <div class="flex items-center">
      <img src="../../assets/images/logo2.png" alt="Company Logo" class="h-9 w-9 mr-2" />
      <h2 class="text-4xl font-bold font-serif text-center my-3 text-red-800">
        Hospital Managment
      </h2>
    </div>
    <button
      @click="showModal"
      class="bg-red-800 text-white font-medium px-4 py-2 rounded-lg"
    >
      Logout
    </button>
  </div>
  <logoutPopup
    :isVisible="isModalVisible"
    @cancelLogout="hideModal"
    @confirmLogout="logoutPage"
  ></logoutPopup>
</template>

<script>
import logoutPopup from "./LogoutPopup.vue";
export default {
  name: "MainHeader",
  components: { logoutPopup },
  data() {
    return {
      isModalVisible: false,
    };
  },
  methods: {
    showModal() {
      this.isModalVisible = true;
    },
    hideModal() {
      this.isModalVisible = false;
    },
    logoutPage() {
      localStorage.removeItem("token");
      this.$router.push("/login");
    },
  },
};
</script>

<style scoped></style>
