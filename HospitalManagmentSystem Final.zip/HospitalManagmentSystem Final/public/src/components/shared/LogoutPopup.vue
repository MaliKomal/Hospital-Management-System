<template>
  <div
    v-if="isVisible"
    class="fixed inset-0 flex items-start justify-end bg-black bg-opacity-50 pt-14 pr-5"
  >
    <div class="bg-white p-8 rounded shadow-md font-medium relative mt-3">
      <p class="my-5 text-lg">Are you sure you want to Logout ?</p>
      <div class="flex justify-center my-5">
        <button
          @click="confirmLogoutPage"
          class="bg-green-800 text-white px-8 py-3 rounded mr-4"
        >
          Yes
        </button>
        <button @click="cancelLogoutPage" class="bg-red-800 text-white px-8 py-2 rounded">
          No
        </button>
      </div>
    </div>
  </div>
</template>

<script>
export default {
  name: "LogoutPopup",

  props: { isVisible: { type: Boolean } },
  emits: ["confirmLogout", "cancelLogout"],

  methods: {
    confirmLogoutPage() {
      this.$emit("confirmLogout");
    },
    cancelLogoutPage() {
      this.$emit("cancelLogout");
    },
  },
};
</script>

<style scoped></style>
