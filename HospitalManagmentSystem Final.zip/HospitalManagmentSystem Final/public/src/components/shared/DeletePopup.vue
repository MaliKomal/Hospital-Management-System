<template>
  <div
    v-if="isVisible"
    class="fixed inset-0 flex items-center justify-center bg-black bg-opacity-50"
  >
    <div class="bg-white p-8 rounded shadow-md font-medium relative">
      <!-- Cross icon -->
      <button @click="cancelDeleteData" class="absolute top-2 right-2 text-black">
        <svg class="h-6 w-6" fill="none" viewBox="0 0 24 24" stroke="currentColor">
          <path
            stroke-linecap="round"
            stroke-linejoin="round"
            stroke-width="2"
            d="M6 18L18 6M6 6l12 12"
          />
        </svg>
      </button>

      <p class="my-10 text-lg">
        Are you sure you want to delete the {{ deletedName }} profile ?
      </p>
      <div class="flex justify-center my-10">
        <button
          @click="confirmDeleteData"
          class="bg-green-800 text-white px-10 py-3 rounded mr-4"
        >
          Delete
        </button>
        <button
          @click="cancelDeleteData"
          class="bg-red-800 text-white px-10 py-2 rounded"
        >
          Cancel
        </button>
      </div>
    </div>
  </div>
</template>

<script>
export default {
  name: "DeletePopup",

  props: {
    isVisible: { type: Boolean },
    deletePostId: { type: Number },
    deletedName: { type: String },
  },
  emits: ["confirmDeletePost", "cancelDeletePost"],

  methods: {
    confirmDeleteData() {
      this.$emit("confirmDeletePost", this.deletePostId);
    },
    cancelDeleteData() {
      this.$emit("cancelDeletePost");
    },
  },
};
</script>

<style scoped></style>
