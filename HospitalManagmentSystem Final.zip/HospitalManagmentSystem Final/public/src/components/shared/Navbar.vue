<template>
  <div class="fixed top-17 w-1/6 h-screen bg-red-800 text-white text-xl pt-5">
    <ul class="mx-5 py-5">
     
      <li class="py-2">
        <router-link
          to="/showPatient"
          class="block p-2"
          :class="{ 'active-link': isShowPatientActive }"
          >Patient</router-link
        >
      </li>
      <li class="py-2">
        <router-link
          to="/showDoctor"
          class="block p-2"
          :class="{ 'active-link': isShowDoctorActive }"
          >Doctor</router-link
        >
      </li>
      <li class="py-2">
        <router-link
          to="/showAppointment"
          class="block p-2"
          :class="{ 'active-link': isShowAppointmentActive }"
        >
          Appointment</router-link
        >
      </li>
      <li class="py-2">
        <router-link
          to="/showBilling"
          class="block p-2"
          :class="{ 'active-link': isShowBillingActive }"
        >
          Billing</router-link
        >
      </li>
    </ul>
  </div>
</template>

<script>
export default {
  name: "Navbar",
  computed: {
    isHomeActive() {
      return this.$route.matched.some((route) => route.name === "Home");
    },
    isShowPatientActive() {
      return this.$route.matched.some(
        (route) =>
          route.name === "ShowPatient" ||
          route.name === "AddPatient" ||
          route.name === "UpdatePatient"
      );
    },
    isShowDoctorActive() {
      return this.$route.matched.some(
        (route) =>
          route.name === "ShowDoctor" ||
          route.name === "AddDoctor" ||
          route.name === "UpdateDoctor"
      );
    },
    isShowAppointmentActive() {
      return this.$route.matched.some(
        (route) =>
          route.name === "ShowAppointment" ||
          route.name === "AddAppointment" ||
          route.name === "UpdateAppointment"
      );
    },
    isShowBillingActive() {
      return this.$route.matched.some(
        (route) =>
          route.name === "ShowBilling" ||
          route.name === "AddBilling" ||
          route.name === "UpdateBilling"
      );
    },
  },
};
</script>

<style scoped>
.active-link {
  /* Your active link styling */
  background-color: white;
  color: rgb(98, 14, 14);
  margin-top: 10px;
  border-radius: 5px;
  font-weight: 600;
}
</style>
