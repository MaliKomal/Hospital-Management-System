// Load environment variables from .env file
require('dotenv').config();
//import express framework
const express = require('express')
//initilize an express application by calling express() function
const cors = require('cors');
const app = express()
// Allow requests from the Vue.js frontend origin
app.use(cors({
    origin: 'http://localhost:5173',
    methods: ['GET', 'POST', 'PATCH', 'DELETE'], // Add other allowed methods as needed
    allowedHeaders: ['Content-Type', 'Authorization'], // Add other allowed headers as needed
    
}));

//import node.js http server
const http = require('http')
// import body-parser module for parsing request bodies
const body_parser = require('body-parser')
//import admin,patient,doctor,biiling,appointmnet routes
const admin_routes = require('./routes/admin')
const patient_routes = require("./routes/patient")
const doctor_routes = require("./routes/doctor")
const billing_routes = require("./routes/billing")
const appoinment_routes = require("./routes/appointment")
// Get port from environment variable
const port = process.env.PORT
const localhost = "127.0.0.1";
// Create HTTP server with Express app
const server = http.createServer(app)

// Middleware to parse JSON bodies
app.use(express.json());
// Middleware to parse x-www-form-urlencoded data
app.use(express.urlencoded({ extended: true }));
app.use(body_parser.json());
app.use(body_parser.urlencoded({ extended: true }))

// Middleware to set up routes for different APIs
app.use("/api/admin", admin_routes)
app.use("/api/patient", patient_routes)
app.use("/api/doctor", doctor_routes)
app.use("/api/appointment", appoinment_routes)
app.use("/api/billing", billing_routes)



// Start the server and listen on the specified port
server.listen(port, localhost, () => {
    console.log("your port is http://" + localhost + ":" + port)
})